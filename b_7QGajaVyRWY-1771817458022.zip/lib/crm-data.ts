// Sample data for AVAIL CRM — Electronic component broker

export type OwnershipHealth = "green" | "yellow" | "red"
export type ActivityType = "email_sent" | "email_received" | "phone" | "note" | "quote" | "offer"
export type ActivitySource = "graph_api" | "8x8" | "manual"
export type RequisitionStatus = "open" | "quoted" | "won" | "lost"
export type RfqStatus = "sent" | "opened" | "replied" | "quoted" | "ghost"
export type ContactStatus = "new" | "researching" | "qualified" | "engaged" | "champion" | "dead_end"

export interface Owner {
  id: string
  name: string
  initials: string
  color: string
}

export interface Contact {
  id: string
  name: string
  title: string
  email: string
  phone: string
  companyId: string
  companyName: string
  type: "customer" | "vendor"
  lastContacted: string
  source: "manual" | "email_mining" | "import" | "api_enrichment"
  aiEnriched: boolean
  isPrimary?: boolean
  siteId?: string
  status: ContactStatus
  department?: string
  notes?: string
  outreachAttempts?: number
}

export interface Activity {
  id: string
  type: ActivityType
  source: ActivitySource
  timestamp: string
  userId: string
  userInitials: string
  summary: string
  contactId?: string
}

export interface CustomerSite {
  id: string
  address: string
  primaryContact: string
  lastRequisitionDate: string
}

export interface Requisition {
  id: string
  partNumber: string
  quantity: number
  status: RequisitionStatus
  value: number
  dateCreated: string
  contactId?: string
}

export interface Company {
  id: string
  name: string
  industry: string
  ownerId: string
  isStrategic: boolean
  lastActivityAt: string
  daysSinceActivity: number
  ownershipHealth: OwnershipHealth
  daysUntilExpiry: number
  siteCount: number
  openRequisitions: number
  sites: CustomerSite[]
  contacts: Contact[]
  activities: Activity[]
  requisitions: Requisition[]
}

export interface VendorContact {
  id: string
  name: string
  title: string
  email: string
  phone: string
  isPrimary: boolean
  autoDiscovered: boolean
}

export interface PartHistory {
  partNumber: string
  lastQuotedDate: string
  lastPrice: number
  quantity: number
  leadTime: string
  outcome: "won" | "lost" | "pending"
}

export interface RfqHistory {
  id: string
  partNumber: string
  dateSent: string
  status: RfqStatus
  quantity: number
}

export interface EngagementFactors {
  responseVelocity: number
  ghostRate: number
  pricingCompetitiveness: number
  volumeConsistency: number
  deliveryReliability: number
}

export interface Vendor {
  id: string
  name: string
  engagementScore: number
  responseRate: number
  totalOffers: number
  lastInteraction: string
  isColdStart: boolean
  factors: EngagementFactors
  contacts: VendorContact[]
  partHistory: PartHistory[]
  rfqHistory: RfqHistory[]
  activities: Activity[]
}

export const owners: Owner[] = [
  { id: "o1", name: "Sarah Chen", initials: "SC", color: "bg-primary" },
  { id: "o2", name: "Mike Torres", initials: "MT", color: "bg-chart-2" },
  { id: "o3", name: "Lisa Park", initials: "LP", color: "bg-chart-3" },
  { id: "o4", name: "James Wright", initials: "JW", color: "bg-chart-4" },
  { id: "o5", name: "Amy Nguyen", initials: "AN", color: "bg-chart-5" },
]

export const companies: Company[] = [
  {
    id: "c1",
    name: "Northrop Grumman",
    industry: "Aerospace & Defense",
    ownerId: "o1",
    isStrategic: true,
    lastActivityAt: "2026-02-20T14:30:00Z",
    daysSinceActivity: 2,
    ownershipHealth: "green",
    daysUntilExpiry: 88,
    siteCount: 3,
    openRequisitions: 4,
    sites: [
      { id: "s1", address: "2980 Fairview Park Dr, Falls Church, VA 22042", primaryContact: "David Kim", lastRequisitionDate: "2026-02-18" },
      { id: "s2", address: "1 Space Park Dr, Redondo Beach, CA 90278", primaryContact: "Rachel Green", lastRequisitionDate: "2026-02-10" },
      { id: "s3", address: "7323 Aviation Blvd, Baltimore, MD 21240", primaryContact: "Tom Bradley", lastRequisitionDate: "2026-01-25" },
    ],
    contacts: [
      // Falls Church, VA — s1
      { id: "ct1", name: "David Kim", title: "Procurement Manager", email: "d.kim@ngc.com", phone: "(703) 555-0142", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-02-20", source: "manual", aiEnriched: false, siteId: "s1", status: "champion", department: "Procurement", outreachAttempts: 12 },
      { id: "ct1b", name: "Angela Torres", title: "Buyer II", email: "a.torres@ngc.com", phone: "(703) 555-0201", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-02-18", source: "email_mining", aiEnriched: true, siteId: "s1", status: "engaged", department: "Procurement", outreachAttempts: 5 },
      { id: "ct1c", name: "James Whitfield", title: "Senior Buyer", email: "j.whitfield@ngc.com", phone: "(703) 555-0215", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-02-12", source: "manual", aiEnriched: false, siteId: "s1", status: "qualified", department: "Procurement", outreachAttempts: 4 },
      { id: "ct1d", name: "Megan Fox", title: "Commodity Manager", email: "m.fox@ngc.com", phone: "(703) 555-0228", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-01-30", source: "api_enrichment", aiEnriched: true, siteId: "s1", status: "researching", department: "Supply Chain", outreachAttempts: 2 },
      { id: "ct1e", name: "Paul Ventura", title: "VP Supply Chain", email: "p.ventura@ngc.com", phone: "(703) 555-0244", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-01-15", source: "api_enrichment", aiEnriched: true, siteId: "s1", status: "new", department: "Executive", outreachAttempts: 0, notes: "Senior decision maker — need intro from David Kim" },
      { id: "ct1f", name: "Nina Patel", title: "ERP Systems Analyst", email: "n.patel@ngc.com", phone: "(703) 555-0259", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-02-05", source: "email_mining", aiEnriched: true, siteId: "s1", status: "dead_end", department: "IT", outreachAttempts: 3, notes: "Not involved in procurement decisions" },
      // Redondo Beach, CA — s2
      { id: "ct2", name: "Rachel Green", title: "Supply Chain Director", email: "r.green@ngc.com", phone: "(310) 555-0198", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-02-15", source: "email_mining", aiEnriched: true, siteId: "s2", status: "champion", department: "Supply Chain", outreachAttempts: 9 },
      { id: "ct2b", name: "Derek Owens", title: "Buyer", email: "d.owens@ngc.com", phone: "(310) 555-0277", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-02-08", source: "manual", aiEnriched: false, siteId: "s2", status: "engaged", department: "Procurement", outreachAttempts: 6 },
      { id: "ct2c", name: "Hana Yoshida", title: "Quality Assurance Lead", email: "h.yoshida@ngc.com", phone: "(310) 555-0293", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-01-22", source: "api_enrichment", aiEnriched: true, siteId: "s2", status: "qualified", department: "Quality", outreachAttempts: 3 },
      { id: "ct2d", name: "Frank Russo", title: "Component Engineer", email: "f.russo@ngc.com", phone: "(310) 555-0310", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-01-10", source: "email_mining", aiEnriched: true, siteId: "s2", status: "researching", department: "Engineering", outreachAttempts: 1 },
      { id: "ct2e", name: "Courtney Blake", title: "Procurement Analyst", email: "c.blake@ngc.com", phone: "(310) 555-0327", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-02-01", source: "import", aiEnriched: false, siteId: "s2", status: "new", department: "Procurement", outreachAttempts: 0 },
      // Baltimore, MD — s3
      { id: "ct3", name: "Tom Bradley", title: "Component Engineer", email: "t.bradley@ngc.com", phone: "(410) 555-0167", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-02-10", source: "api_enrichment", aiEnriched: true, siteId: "s3", status: "engaged", department: "Engineering", outreachAttempts: 7 },
      { id: "ct3b", name: "Sandra Cole", title: "Procurement Specialist", email: "s.cole@ngc.com", phone: "(410) 555-0183", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-02-17", source: "manual", aiEnriched: false, siteId: "s3", status: "qualified", department: "Procurement", outreachAttempts: 4 },
      { id: "ct3c", name: "Miguel Herrera", title: "Program Director", email: "m.herrera@ngc.com", phone: "(410) 555-0199", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2025-12-15", source: "api_enrichment", aiEnriched: true, siteId: "s3", status: "new", department: "Programs", outreachAttempts: 0, notes: "Runs the sensor platform program — high value target" },
      { id: "ct3d", name: "Wendy Liu", title: "Buyer III", email: "w.liu@ngc.com", phone: "(410) 555-0212", companyId: "c1", companyName: "Northrop Grumman", type: "customer", lastContacted: "2026-01-28", source: "email_mining", aiEnriched: true, siteId: "s3", status: "researching", department: "Procurement", outreachAttempts: 2 },
    ],
    activities: [
      { id: "a1", type: "email_received", source: "graph_api", timestamp: "2026-02-20T14:30:00Z", userId: "o1", userInitials: "SC", summary: "RFQ received for 500x STM32F407VGT6 — urgent need", contactId: "ct1" },
      { id: "a2", type: "quote", source: "manual", timestamp: "2026-02-19T11:00:00Z", userId: "o1", userInitials: "SC", summary: "Quote sent: $12.40/ea for STM32F4 batch", contactId: "ct1" },
      { id: "a3", type: "email_sent", source: "graph_api", timestamp: "2026-02-18T09:15:00Z", userId: "o1", userInitials: "SC", summary: "Followed up on LM7805CT lead time availability", contactId: "ct2" },
      { id: "a4", type: "phone", source: "8x8", timestamp: "2026-02-15T16:00:00Z", userId: "o1", userInitials: "SC", summary: "Call with David Kim re: Q2 forecast — 3 new line items", contactId: "ct1" },
      { id: "a5", type: "note", source: "manual", timestamp: "2026-02-12T10:30:00Z", userId: "o1", userInitials: "SC", summary: "Customer moving to STM32H7 series for next-gen platform" },
      { id: "a6", type: "offer", source: "manual", timestamp: "2026-02-10T13:45:00Z", userId: "o1", userInitials: "SC", summary: "Offer submitted: 1000x MAX232CPE at $1.85/ea", contactId: "ct3" },
    ],
    requisitions: [
      { id: "r1", partNumber: "STM32F407VGT6", quantity: 500, status: "open", value: 6200, dateCreated: "2026-02-20", contactId: "ct1" },
      { id: "r2", partNumber: "LM7805CT", quantity: 2000, status: "quoted", value: 1800, dateCreated: "2026-02-15", contactId: "ct2" },
      { id: "r3", partNumber: "MAX232CPE", quantity: 1000, status: "won", value: 1850, dateCreated: "2026-02-10", contactId: "ct3" },
      { id: "r4", partNumber: "TPS54302DDCR", quantity: 3000, status: "open", value: 4500, dateCreated: "2026-02-08", contactId: "ct1" },
    ],
  },
  {
    id: "c2",
    name: "Raytheon Technologies",
    industry: "Aerospace & Defense",
    ownerId: "o2",
    isStrategic: true,
    lastActivityAt: "2026-02-18T09:00:00Z",
    daysSinceActivity: 4,
    ownershipHealth: "green",
    daysUntilExpiry: 86,
    siteCount: 2,
    openRequisitions: 2,
    sites: [
      { id: "s4", address: "1151 E Hermans Rd, Tucson, AZ 85706", primaryContact: "Jennifer Miles", lastRequisitionDate: "2026-02-16" },
      { id: "s5", address: "870 Winter St, Waltham, MA 02451", primaryContact: "Robert Chang", lastRequisitionDate: "2026-02-01" },
    ],
    contacts: [
      { id: "ct4", name: "Jennifer Miles", title: "Senior Buyer", email: "j.miles@rtx.com", phone: "(520) 555-0134", companyId: "c2", companyName: "Raytheon Technologies", type: "customer", lastContacted: "2026-02-18", source: "manual", aiEnriched: false, siteId: "s4", status: "champion", department: "Procurement", outreachAttempts: 14 },
      { id: "ct5", name: "Robert Chang", title: "Program Manager", email: "r.chang@rtx.com", phone: "(781) 555-0189", companyId: "c2", companyName: "Raytheon Technologies", type: "customer", lastContacted: "2026-02-05", source: "email_mining", aiEnriched: true, siteId: "s5", status: "engaged", department: "Programs", outreachAttempts: 8 },
      { id: "ct4b", name: "Alan Porter", title: "Commodity Manager", email: "a.porter@rtx.com", phone: "(520) 555-0148", companyId: "c2", companyName: "Raytheon Technologies", type: "customer", lastContacted: "2026-02-10", source: "manual", aiEnriched: false, siteId: "s4", status: "qualified", department: "Supply Chain", outreachAttempts: 5 },
      { id: "ct4c", name: "Diane Keller", title: "VP Procurement", email: "d.keller@rtx.com", phone: "(520) 555-0165", companyId: "c2", companyName: "Raytheon Technologies", type: "customer", lastContacted: "2026-01-12", source: "api_enrichment", aiEnriched: true, siteId: "s4", status: "new", department: "Executive", outreachAttempts: 0, notes: "C-level procurement — ask Jennifer for intro" },
      { id: "ct5b", name: "Larry Grant", title: "Design Engineer", email: "l.grant@rtx.com", phone: "(781) 555-0201", companyId: "c2", companyName: "Raytheon Technologies", type: "customer", lastContacted: "2026-01-28", source: "email_mining", aiEnriched: true, siteId: "s5", status: "researching", department: "Engineering", outreachAttempts: 2 },
      { id: "ct5c", name: "Priya Sharma", title: "Buyer", email: "p.sharma@rtx.com", phone: "(781) 555-0218", companyId: "c2", companyName: "Raytheon Technologies", type: "customer", lastContacted: "2026-02-14", source: "import", aiEnriched: false, siteId: "s5", status: "engaged", department: "Procurement", outreachAttempts: 6 },
    ],
    activities: [
      { id: "a7", type: "email_sent", source: "graph_api", timestamp: "2026-02-18T09:00:00Z", userId: "o2", userInitials: "MT", summary: "Sent revised pricing for AD8221ARZ batch order", contactId: "ct4" },
      { id: "a8", type: "phone", source: "8x8", timestamp: "2026-02-14T14:30:00Z", userId: "o2", userInitials: "MT", summary: "Quarterly review call with Jennifer — expanding scope to ICs", contactId: "ct4" },
      { id: "a9", type: "quote", source: "manual", timestamp: "2026-02-10T11:00:00Z", userId: "o2", userInitials: "MT", summary: "Quote: 200x AD8221ARZ at $8.50/ea", contactId: "ct4" },
    ],
    requisitions: [
      { id: "r5", partNumber: "AD8221ARZ", quantity: 200, status: "quoted", value: 1700, dateCreated: "2026-02-16", contactId: "ct4" },
      { id: "r6", partNumber: "LTC3780EGN", quantity: 500, status: "open", value: 3750, dateCreated: "2026-02-01", contactId: "ct5" },
    ],
  },
  {
    id: "c3",
    name: "Flex Ltd",
    industry: "Contract Manufacturing",
    ownerId: "o3",
    isStrategic: false,
    lastActivityAt: "2026-02-01T10:00:00Z",
    daysSinceActivity: 21,
    ownershipHealth: "yellow",
    daysUntilExpiry: 9,
    siteCount: 1,
    openRequisitions: 1,
    sites: [
      { id: "s6", address: "6201 America Center Dr, San Jose, CA 95002", primaryContact: "Mark Sullivan", lastRequisitionDate: "2026-01-28" },
    ],
    contacts: [
      { id: "ct6", name: "Mark Sullivan", title: "Commodity Manager", email: "m.sullivan@flex.com", phone: "(408) 555-0176", companyId: "c3", companyName: "Flex Ltd", type: "customer", lastContacted: "2026-02-01", source: "import", aiEnriched: false, siteId: "s6", status: "engaged", department: "Procurement", outreachAttempts: 5 },
      { id: "ct6b", name: "Amy Chen", title: "Buyer", email: "a.chen@flex.com", phone: "(408) 555-0190", companyId: "c3", companyName: "Flex Ltd", type: "customer", lastContacted: "2026-01-20", source: "email_mining", aiEnriched: true, siteId: "s6", status: "qualified", department: "Procurement", outreachAttempts: 3 },
      { id: "ct6c", name: "Bill Henderson", title: "Program Manager", email: "b.henderson@flex.com", phone: "(408) 555-0207", companyId: "c3", companyName: "Flex Ltd", type: "customer", lastContacted: "2025-12-10", source: "api_enrichment", aiEnriched: true, siteId: "s6", status: "new", department: "Programs", outreachAttempts: 0, notes: "Need to find right entry point" },
    ],
    activities: [
      { id: "a10", type: "email_sent", source: "graph_api", timestamp: "2026-02-01T10:00:00Z", userId: "o3", userInitials: "LP", summary: "Sent availability update on TL431ACDR — 5k in stock", contactId: "ct6" },
      { id: "a11", type: "note", source: "manual", timestamp: "2026-01-25T15:00:00Z", userId: "o3", userInitials: "LP", summary: "Low volume account — may not renew without new program wins" },
    ],
    requisitions: [
      { id: "r7", partNumber: "TL431ACDR", quantity: 5000, status: "open", value: 750, dateCreated: "2026-01-28", contactId: "ct6" },
    ],
  },
  {
    id: "c4",
    name: "Honeywell Aerospace",
    industry: "Aerospace & Defense",
    ownerId: "o4",
    isStrategic: false,
    lastActivityAt: "2026-01-26T11:00:00Z",
    daysSinceActivity: 27,
    ownershipHealth: "red",
    daysUntilExpiry: 3,
    siteCount: 2,
    openRequisitions: 3,
    sites: [
      { id: "s7", address: "1944 E Sky Harbor Cir, Phoenix, AZ 85034", primaryContact: "Karen White", lastRequisitionDate: "2026-01-20" },
      { id: "s8", address: "101 Columbia Rd, Morristown, NJ 07962", primaryContact: "Steve Lee", lastRequisitionDate: "2026-01-15" },
    ],
    contacts: [
      { id: "ct7", name: "Karen White", title: "Procurement Lead", email: "k.white@honeywell.com", phone: "(602) 555-0143", companyId: "c4", companyName: "Honeywell Aerospace", type: "customer", lastContacted: "2026-01-26", source: "manual", aiEnriched: false, siteId: "s7", status: "champion", department: "Procurement", outreachAttempts: 10 },
      { id: "ct8", name: "Steve Lee", title: "Design Engineer", email: "s.lee@honeywell.com", phone: "(973) 555-0188", companyId: "c4", companyName: "Honeywell Aerospace", type: "customer", lastContacted: "2026-01-15", source: "api_enrichment", aiEnriched: true, siteId: "s8", status: "qualified", department: "Engineering", outreachAttempts: 4 },
      { id: "ct7b", name: "Ron Vega", title: "Senior Buyer", email: "r.vega@honeywell.com", phone: "(602) 555-0159", companyId: "c4", companyName: "Honeywell Aerospace", type: "customer", lastContacted: "2026-02-02", source: "manual", aiEnriched: false, siteId: "s7", status: "engaged", department: "Procurement", outreachAttempts: 7 },
      { id: "ct8b", name: "Tina Marshall", title: "Quality Engineer", email: "t.marshall@honeywell.com", phone: "(973) 555-0201", companyId: "c4", companyName: "Honeywell Aerospace", type: "customer", lastContacted: "2026-01-05", source: "email_mining", aiEnriched: true, siteId: "s8", status: "researching", department: "Quality", outreachAttempts: 1 },
    ],
    activities: [
      { id: "a12", type: "email_received", source: "graph_api", timestamp: "2026-01-26T11:00:00Z", userId: "o4", userInitials: "JW", summary: "Request for 750x SN74HC595N — need by March", contactId: "ct7" },
      { id: "a13", type: "phone", source: "8x8", timestamp: "2026-01-20T09:00:00Z", userId: "o4", userInitials: "JW", summary: "Brief call with Karen — confirming part specs for SN74HC595N", contactId: "ct7" },
    ],
    requisitions: [
      { id: "r8", partNumber: "SN74HC595N", quantity: 750, status: "open", value: 375, dateCreated: "2026-01-26", contactId: "ct7" },
      { id: "r9", partNumber: "IRF540NPBF", quantity: 1200, status: "quoted", value: 1560, dateCreated: "2026-01-20", contactId: "ct7" },
      { id: "r10", partNumber: "LM317T", quantity: 3000, status: "lost", value: 2100, dateCreated: "2026-01-10", contactId: "ct8" },
    ],
  },
  {
    id: "c5",
    name: "L3Harris Technologies",
    industry: "Aerospace & Defense",
    ownerId: "o5",
    isStrategic: false,
    lastActivityAt: "2026-02-19T16:00:00Z",
    daysSinceActivity: 3,
    ownershipHealth: "green",
    daysUntilExpiry: 27,
    siteCount: 1,
    openRequisitions: 2,
    sites: [
      { id: "s9", address: "1025 W NASA Blvd, Melbourne, FL 32919", primaryContact: "Patricia Hall", lastRequisitionDate: "2026-02-17" },
    ],
    contacts: [
      { id: "ct9", name: "Patricia Hall", title: "Supply Chain Manager", email: "p.hall@l3harris.com", phone: "(321) 555-0155", companyId: "c5", companyName: "L3Harris Technologies", type: "customer", lastContacted: "2026-02-19", source: "manual", aiEnriched: false, siteId: "s9", status: "champion", department: "Supply Chain", outreachAttempts: 11 },
      { id: "ct9b", name: "George Ellis", title: "Senior Buyer", email: "g.ellis@l3harris.com", phone: "(321) 555-0168", companyId: "c5", companyName: "L3Harris Technologies", type: "customer", lastContacted: "2026-02-11", source: "manual", aiEnriched: false, siteId: "s9", status: "engaged", department: "Procurement", outreachAttempts: 7 },
      { id: "ct9c", name: "Lisa Tran", title: "Test Engineer", email: "l.tran@l3harris.com", phone: "(321) 555-0182", companyId: "c5", companyName: "L3Harris Technologies", type: "customer", lastContacted: "2026-01-30", source: "api_enrichment", aiEnriched: true, siteId: "s9", status: "researching", department: "Engineering", outreachAttempts: 2 },
    ],
    activities: [
      { id: "a14", type: "email_received", source: "graph_api", timestamp: "2026-02-19T16:00:00Z", userId: "o5", userInitials: "AN", summary: "New RFQ: 400x ADS1115IDGSR for sensor module", contactId: "ct9" },
      { id: "a15", type: "quote", source: "manual", timestamp: "2026-02-17T10:00:00Z", userId: "o5", userInitials: "AN", summary: "Quote sent: 2000x NE555P at $0.32/ea", contactId: "ct9" },
    ],
    requisitions: [
      { id: "r11", partNumber: "ADS1115IDGSR", quantity: 400, status: "open", value: 2800, dateCreated: "2026-02-19", contactId: "ct9" },
      { id: "r12", partNumber: "NE555P", quantity: 2000, status: "quoted", value: 640, dateCreated: "2026-02-14", contactId: "ct9" },
    ],
  },
  {
    id: "c6",
    name: "Jabil Inc",
    industry: "Contract Manufacturing",
    ownerId: "o1",
    isStrategic: false,
    lastActivityAt: "2026-02-05T14:00:00Z",
    daysSinceActivity: 17,
    ownershipHealth: "yellow",
    daysUntilExpiry: 13,
    siteCount: 1,
    openRequisitions: 1,
    sites: [
      { id: "s10", address: "10560 Dr MLK Jr St N, St. Petersburg, FL 33716", primaryContact: "Dan Morris", lastRequisitionDate: "2026-02-03" },
    ],
    contacts: [
      { id: "ct10", name: "Dan Morris", title: "Buyer", email: "d.morris@jabil.com", phone: "(727) 555-0132", companyId: "c6", companyName: "Jabil Inc", type: "customer", lastContacted: "2026-02-05", source: "import", aiEnriched: false, siteId: "s10", status: "engaged", department: "Procurement", outreachAttempts: 6 },
      { id: "ct10b", name: "Kathy Bloom", title: "VP Operations", email: "k.bloom@jabil.com", phone: "(727) 555-0147", companyId: "c6", companyName: "Jabil Inc", type: "customer", lastContacted: "2026-01-08", source: "api_enrichment", aiEnriched: true, siteId: "s10", status: "new", department: "Executive", outreachAttempts: 0, notes: "Decision maker — Dan needs to make introduction" },
    ],
    activities: [
      { id: "a16", type: "email_sent", source: "graph_api", timestamp: "2026-02-05T14:00:00Z", userId: "o1", userInitials: "SC", summary: "Sent updated MOQ pricing for ATMEGA328P-PU", contactId: "ct10" },
    ],
    requisitions: [
      { id: "r13", partNumber: "ATMEGA328P-PU", quantity: 10000, status: "quoted", value: 25000, dateCreated: "2026-02-03", contactId: "ct10" },
    ],
  },
]

export const vendors: Vendor[] = [
  {
    id: "v1",
    name: "Arrow Electronics",
    engagementScore: 87,
    responseRate: 94,
    totalOffers: 156,
    lastInteraction: "2026-02-21T10:00:00Z",
    isColdStart: false,
    factors: { responseVelocity: 92, ghostRate: 88, pricingCompetitiveness: 78, volumeConsistency: 90, deliveryReliability: 87 },
    contacts: [
      { id: "vc1", name: "Linda Park", title: "Account Manager", email: "l.park@arrow.com", phone: "(631) 555-0145", isPrimary: true, autoDiscovered: false },
      { id: "vc2", name: "Chris Johnson", title: "Inside Sales", email: "c.johnson@arrow.com", phone: "(631) 555-0167", isPrimary: false, autoDiscovered: true },
    ],
    partHistory: [
      { partNumber: "STM32F407VGT6", lastQuotedDate: "2026-02-20", lastPrice: 11.80, quantity: 500, leadTime: "4-6 weeks", outcome: "won" },
      { partNumber: "LM7805CT", lastQuotedDate: "2026-02-15", lastPrice: 0.85, quantity: 2000, leadTime: "Stock", outcome: "pending" },
      { partNumber: "MAX232CPE", lastQuotedDate: "2026-02-08", lastPrice: 1.92, quantity: 1000, leadTime: "2-3 weeks", outcome: "lost" },
      { partNumber: "TPS54302DDCR", lastQuotedDate: "2026-01-30", lastPrice: 1.45, quantity: 3000, leadTime: "8-10 weeks", outcome: "pending" },
    ],
    rfqHistory: [
      { id: "rfq1", partNumber: "STM32F407VGT6", dateSent: "2026-02-19", status: "quoted", quantity: 500 },
      { id: "rfq2", partNumber: "LM7805CT", dateSent: "2026-02-14", status: "replied", quantity: 2000 },
      { id: "rfq3", partNumber: "ATMEGA328P-PU", dateSent: "2026-02-10", status: "quoted", quantity: 10000 },
    ],
    activities: [
      { id: "va1", type: "email_received", source: "graph_api", timestamp: "2026-02-21T10:00:00Z", userId: "o1", userInitials: "SC", summary: "Pricing update received for STM32 line — competitive" },
      { id: "va2", type: "email_sent", source: "graph_api", timestamp: "2026-02-19T09:00:00Z", userId: "o1", userInitials: "SC", summary: "RFQ sent for 500x STM32F407VGT6" },
    ],
  },
  {
    id: "v2",
    name: "Digi-Key Electronics",
    engagementScore: 82,
    responseRate: 91,
    totalOffers: 203,
    lastInteraction: "2026-02-20T15:00:00Z",
    isColdStart: false,
    factors: { responseVelocity: 95, ghostRate: 82, pricingCompetitiveness: 72, volumeConsistency: 85, deliveryReliability: 76 },
    contacts: [
      { id: "vc3", name: "Sara Williams", title: "Corporate Sales", email: "s.williams@digikey.com", phone: "(218) 555-0134", isPrimary: true, autoDiscovered: false },
    ],
    partHistory: [
      { partNumber: "NE555P", lastQuotedDate: "2026-02-17", lastPrice: 0.28, quantity: 2000, leadTime: "Stock", outcome: "won" },
      { partNumber: "LM317T", lastQuotedDate: "2026-02-05", lastPrice: 0.65, quantity: 3000, leadTime: "Stock", outcome: "won" },
    ],
    rfqHistory: [
      { id: "rfq4", partNumber: "NE555P", dateSent: "2026-02-16", status: "quoted", quantity: 2000 },
      { id: "rfq5", partNumber: "AD8221ARZ", dateSent: "2026-02-12", status: "ghost", quantity: 200 },
    ],
    activities: [
      { id: "va3", type: "email_received", source: "graph_api", timestamp: "2026-02-20T15:00:00Z", userId: "o5", userInitials: "AN", summary: "NE555P stock confirmation — 15k available" },
    ],
  },
  {
    id: "v3",
    name: "Mouser Electronics",
    engagementScore: 75,
    responseRate: 85,
    totalOffers: 134,
    lastInteraction: "2026-02-18T11:00:00Z",
    isColdStart: false,
    factors: { responseVelocity: 80, ghostRate: 75, pricingCompetitiveness: 70, volumeConsistency: 78, deliveryReliability: 72 },
    contacts: [
      { id: "vc4", name: "Brian Cooper", title: "Enterprise Sales", email: "b.cooper@mouser.com", phone: "(817) 555-0198", isPrimary: true, autoDiscovered: false },
      { id: "vc5", name: "Emily Ross", title: "Pricing Analyst", email: "e.ross@mouser.com", phone: "(817) 555-0211", isPrimary: false, autoDiscovered: true },
    ],
    partHistory: [
      { partNumber: "TL431ACDR", lastQuotedDate: "2026-02-15", lastPrice: 0.14, quantity: 5000, leadTime: "Stock", outcome: "pending" },
      { partNumber: "IRF540NPBF", lastQuotedDate: "2026-02-10", lastPrice: 1.20, quantity: 1200, leadTime: "3-4 weeks", outcome: "won" },
    ],
    rfqHistory: [
      { id: "rfq6", partNumber: "TL431ACDR", dateSent: "2026-02-14", status: "quoted", quantity: 5000 },
      { id: "rfq7", partNumber: "SN74HC595N", dateSent: "2026-02-08", status: "replied", quantity: 750 },
    ],
    activities: [
      { id: "va4", type: "email_sent", source: "graph_api", timestamp: "2026-02-18T11:00:00Z", userId: "o3", userInitials: "LP", summary: "Follow-up on TL431ACDR pricing — need best and final" },
    ],
  },
  {
    id: "v4",
    name: "Smith & Associates",
    engagementScore: 56,
    responseRate: 62,
    totalOffers: 45,
    lastInteraction: "2026-02-12T09:00:00Z",
    isColdStart: false,
    factors: { responseVelocity: 50, ghostRate: 45, pricingCompetitiveness: 68, volumeConsistency: 60, deliveryReliability: 57 },
    contacts: [
      { id: "vc6", name: "Jason Clark", title: "Sales Director", email: "j.clark@smithweb.com", phone: "(713) 555-0156", isPrimary: true, autoDiscovered: false },
    ],
    partHistory: [
      { partNumber: "AD8221ARZ", lastQuotedDate: "2026-02-08", lastPrice: 7.90, quantity: 200, leadTime: "6-8 weeks", outcome: "pending" },
    ],
    rfqHistory: [
      { id: "rfq8", partNumber: "AD8221ARZ", dateSent: "2026-02-06", status: "quoted", quantity: 200 },
      { id: "rfq9", partNumber: "LTC3780EGN", dateSent: "2026-01-28", status: "ghost", quantity: 500 },
    ],
    activities: [
      { id: "va5", type: "email_received", source: "graph_api", timestamp: "2026-02-12T09:00:00Z", userId: "o2", userInitials: "MT", summary: "Partial quote on AD8221ARZ — extended lead time" },
    ],
  },
  {
    id: "v5",
    name: "Rochester Electronics",
    engagementScore: 34,
    responseRate: 38,
    totalOffers: 18,
    lastInteraction: "2026-01-20T14:00:00Z",
    isColdStart: false,
    factors: { responseVelocity: 30, ghostRate: 25, pricingCompetitiveness: 45, volumeConsistency: 35, deliveryReliability: 35 },
    contacts: [
      { id: "vc7", name: "Mike Adams", title: "Account Executive", email: "m.adams@rocelec.com", phone: "(978) 555-0143", isPrimary: true, autoDiscovered: false },
    ],
    partHistory: [
      { partNumber: "LM317T", lastQuotedDate: "2026-01-15", lastPrice: 0.90, quantity: 3000, leadTime: "10-12 weeks", outcome: "lost" },
    ],
    rfqHistory: [
      { id: "rfq10", partNumber: "LM317T", dateSent: "2026-01-12", status: "quoted", quantity: 3000 },
      { id: "rfq11", partNumber: "NE555P", dateSent: "2026-01-05", status: "ghost", quantity: 2000 },
      { id: "rfq12", partNumber: "STM32F407VGT6", dateSent: "2025-12-20", status: "ghost", quantity: 500 },
    ],
    activities: [
      { id: "va6", type: "email_received", source: "graph_api", timestamp: "2026-01-20T14:00:00Z", userId: "o4", userInitials: "JW", summary: "Late response on LM317T — pricing non-competitive" },
    ],
  },
  {
    id: "v6",
    name: "Verical (TTI)",
    engagementScore: 0,
    responseRate: 0,
    totalOffers: 0,
    lastInteraction: "2026-02-21T08:00:00Z",
    isColdStart: true,
    factors: { responseVelocity: 0, ghostRate: 0, pricingCompetitiveness: 0, volumeConsistency: 0, deliveryReliability: 0 },
    contacts: [
      { id: "vc8", name: "Anna Lopez", title: "New Business Rep", email: "a.lopez@verical.com", phone: "(817) 555-0277", isPrimary: true, autoDiscovered: true },
    ],
    partHistory: [],
    rfqHistory: [
      { id: "rfq13", partNumber: "TPS54302DDCR", dateSent: "2026-02-21", status: "sent", quantity: 3000 },
    ],
    activities: [
      { id: "va7", type: "email_sent", source: "graph_api", timestamp: "2026-02-21T08:00:00Z", userId: "o1", userInitials: "SC", summary: "Initial RFQ sent — testing new vendor channel" },
    ],
  },
]

export function getOwner(ownerId: string): Owner {
  return owners.find((o) => o.id === ownerId) || owners[0]
}

export function getContactById(contactId: string): Contact | undefined {
  for (const company of companies) {
    const found = company.contacts.find((c) => c.id === contactId)
    if (found) return found
  }
  return undefined
}

export function getRelativeTime(dateStr: string): string {
  const now = new Date("2026-02-22T12:00:00Z")
  const date = new Date(dateStr)
  const diffMs = now.getTime() - date.getTime()
  const diffMins = Math.floor(diffMs / 60000)
  const diffHours = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffMs / 86400000)

  if (diffMins < 60) return `${diffMins}m ago`
  if (diffHours < 24) return `${diffHours}h ago`
  if (diffDays < 30) return `${diffDays}d ago`
  return `${Math.floor(diffDays / 30)}mo ago`
}

export function getAllContacts(): Contact[] {
  const customerContacts = companies.flatMap((c) => c.contacts)
  const vendorContacts = vendors.flatMap((v) =>
    v.contacts.map((vc) => ({
      id: vc.id,
      name: vc.name,
      title: vc.title,
      email: vc.email,
      phone: vc.phone,
      companyId: v.id,
      companyName: v.name,
      type: "vendor" as const,
      lastContacted: v.lastInteraction.split("T")[0],
      source: vc.autoDiscovered ? ("email_mining" as const) : ("manual" as const),
      aiEnriched: false,
      isPrimary: vc.isPrimary,
      status: "engaged" as ContactStatus,
    }))
  )
  return [...customerContacts, ...vendorContacts]
}

export function getEngagementColor(score: number): string {
  if (score >= 70) return "text-success"
  if (score >= 40) return "text-warning"
  return "text-destructive"
}

export function getEngagementStroke(score: number): string {
  if (score >= 70) return "#22c55e"
  if (score >= 40) return "#f59e0b"
  return "#ef4444"
}

export function getHealthColor(health: OwnershipHealth): string {
  if (health === "green") return "bg-success"
  if (health === "yellow") return "bg-warning"
  return "bg-destructive"
}
