"use client"

import { useState, useCallback, useMemo } from "react"
import { cn } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip"
import {
  Search,
  ArrowUpDown,
  Star,
  Mail,
  MailOpen,
  Phone,
  StickyNote,
  FileText,
  Tag,
  ChevronDown,
  ChevronRight,
  Sparkles,
  MapPin,
  User,
  Filter,
  Users,
  Target,
  CircleDot,
  MessageSquare,
  UserCheck,
  UserX,
  CircleHelp,
} from "lucide-react"
import {
  companies,
  getOwner,
  getRelativeTime,
  getHealthColor,
  getContactById,
  type Company,
  type Activity,
  type ContactStatus,
} from "@/lib/crm-data"

/* ── Status configuration ────────────────────────────────── */

const STATUS_CONFIG: Record<
  ContactStatus,
  { label: string; color: string; bg: string; icon: typeof Target }
> = {
  new: { label: "New", color: "text-chart-3", bg: "bg-chart-3/10", icon: CircleDot },
  researching: { label: "Researching", color: "text-chart-4", bg: "bg-chart-4/10", icon: CircleHelp },
  qualified: { label: "Qualified", color: "text-primary", bg: "bg-primary/10", icon: Target },
  engaged: { label: "Engaged", color: "text-chart-2", bg: "bg-chart-2/10", icon: MessageSquare },
  champion: { label: "Champion", color: "text-success", bg: "bg-success/10", icon: UserCheck },
  dead_end: { label: "Dead End", color: "text-muted-foreground", bg: "bg-muted", icon: UserX },
}

const STATUS_ORDER: ContactStatus[] = ["champion", "engaged", "qualified", "researching", "new", "dead_end"]

/* ── Shared small components ────────────────────────────── */

function ActivityIcon({ type }: { type: Activity["type"] }) {
  const classes = "size-3.5"
  switch (type) {
    case "email_sent":
      return <Mail className={cn(classes, "text-chart-3")} />
    case "email_received":
      return <MailOpen className={cn(classes, "text-primary")} />
    case "phone":
      return <Phone className={cn(classes, "text-chart-2")} />
    case "note":
      return <StickyNote className={cn(classes, "text-muted-foreground")} />
    case "quote":
      return <FileText className={cn(classes, "text-chart-4")} />
    case "offer":
      return <Tag className={cn(classes, "text-chart-5")} />
  }
}

function SourceTag({ source }: { source: Activity["source"] }) {
  const label = source === "graph_api" ? "via Graph API" : source === "8x8" ? "via 8x8" : "manual"
  return <span className="text-[10px] text-muted-foreground/70">{label}</span>
}

function OwnerAvatar({ ownerId }: { ownerId: string }) {
  const owner = getOwner(ownerId)
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div
          className={cn(
            "flex size-6 items-center justify-center rounded-full text-[10px] font-medium text-primary-foreground",
            owner.color
          )}
        >
          {owner.initials}
        </div>
      </TooltipTrigger>
      <TooltipContent>{owner.name}</TooltipContent>
    </Tooltip>
  )
}

function StatusBadge({ status, compact }: { status: ContactStatus; compact?: boolean }) {
  const config = STATUS_CONFIG[status]
  const Icon = config.icon
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full font-medium",
        config.color,
        config.bg,
        compact ? "px-1.5 py-0.5 text-[10px]" : "px-2 py-0.5 text-[11px]"
      )}
    >
      <Icon className={compact ? "size-2.5" : "size-3"} />
      {config.label}
    </span>
  )
}

/* ── Contact health color based on 30-day rule ─────────── */

function getContactHealthColor(lastContacted: string): string {
  const now = new Date("2026-02-22T12:00:00Z")
  const last = new Date(lastContacted + (lastContacted.includes("T") ? "" : "T12:00:00Z"))
  const diffDays = Math.floor((now.getTime() - last.getTime()) / 86400000)
  if (diffDays <= 7) return "bg-success"
  if (diffDays <= 21) return "bg-warning"
  return "bg-destructive"
}

function getContactHealthLabel(lastContacted: string): string {
  const now = new Date("2026-02-22T12:00:00Z")
  const last = new Date(lastContacted + (lastContacted.includes("T") ? "" : "T12:00:00Z"))
  const diffDays = Math.floor((now.getTime() - last.getTime()) / 86400000)
  return `${diffDays}d ago`
}

/* ── Relationship Health Bar (30-day rule) ─────────────── */

function RelationshipHealthBar({ company }: { company: Company }) {
  const now = new Date("2026-02-22T12:00:00Z")
  let mostRecentMs = 0
  for (const contact of company.contacts) {
    const d = new Date(contact.lastContacted + "T12:00:00Z").getTime()
    if (d > mostRecentMs) mostRecentMs = d
  }
  const elapsed = Math.floor((now.getTime() - mostRecentMs) / 86400000)
  const maxDays = 30
  const remaining = maxDays - elapsed
  const pct = Math.min((elapsed / maxDays) * 100, 100)

  const barColor = elapsed <= 7 ? "bg-success" : elapsed <= 21 ? "bg-warning" : "bg-destructive"
  const textColor = elapsed > 21 ? "text-destructive" : elapsed > 7 ? "text-warning" : "text-foreground"

  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">Relationship Health</span>
        <span className={cn("font-medium", textColor)}>
          {remaining <= 0 ? "Requires contact" : `${remaining}d remaining`}
        </span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
        <div className={cn("h-full rounded-full transition-all", barColor)} style={{ width: `${pct}%` }} />
      </div>
      <div className="flex items-center justify-between text-[10px] text-muted-foreground">
        <span>{elapsed}d since last contact</span>
        <span>30d window</span>
      </div>
    </div>
  )
}

/* ── Contact Status Summary (qualification funnel) ───── */

function ContactStatusSummary({
  company,
  statusOverrides,
}: {
  company: Company
  statusOverrides?: Record<string, ContactStatus>
}) {
  const counts = useMemo(() => {
    const map: Record<ContactStatus, number> = {
      new: 0,
      researching: 0,
      qualified: 0,
      engaged: 0,
      champion: 0,
      dead_end: 0,
    }
    for (const c of company.contacts) {
      const st = statusOverrides?.[c.id] ?? c.status
      map[st] = (map[st] || 0) + 1
    }
    return map
  }, [company.contacts, statusOverrides])

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">Contact Qualification</span>
        <span className="text-xs font-medium text-foreground">{company.contacts.length} total</span>
      </div>
      <div className="flex h-2 w-full overflow-hidden rounded-full">
        {STATUS_ORDER.filter((s) => counts[s] > 0 && s !== "dead_end").map((status) => {
          const config = STATUS_CONFIG[status]
          const pct = (counts[status] / company.contacts.length) * 100
          const colorMap: Record<string, string> = {
            champion: "bg-success",
            engaged: "bg-chart-2",
            qualified: "bg-primary",
            researching: "bg-chart-4",
            new: "bg-chart-3",
          }
          return (
            <Tooltip key={status}>
              <TooltipTrigger asChild>
                <div className={cn("h-full", colorMap[status])} style={{ width: `${pct}%` }} />
              </TooltipTrigger>
              <TooltipContent>
                {config.label}: {counts[status]}
              </TooltipContent>
            </Tooltip>
          )
        })}
        {counts.dead_end > 0 && (
          <Tooltip>
            <TooltipTrigger asChild>
              <div
                className="h-full bg-muted-foreground/30"
                style={{ width: `${(counts.dead_end / company.contacts.length) * 100}%` }}
              />
            </TooltipTrigger>
            <TooltipContent>Dead End: {counts.dead_end}</TooltipContent>
          </Tooltip>
        )}
      </div>
      <div className="flex flex-wrap gap-x-3 gap-y-1">
        {STATUS_ORDER.filter((s) => counts[s] > 0).map((status) => {
          const config = STATUS_CONFIG[status]
          return (
            <span key={status} className={cn("text-[10px] font-medium", config.color)}>
              {counts[status]} {config.label}
            </span>
          )
        })}
      </div>
    </div>
  )
}

/* ── Company list (left panel) ─────────────────────────── */

function CompanyList({
  selected,
  onSelect,
}: {
  selected: string
  onSelect: (id: string) => void
}) {
  const [search, setSearch] = useState("")
  const [sortBy, setSortBy] = useState<"name" | "activity" | "owner">("name")

  const filtered = companies
    .filter((c) => c.name.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === "name") return a.name.localeCompare(b.name)
      if (sortBy === "activity") return a.daysSinceActivity - b.daysSinceActivity
      return getOwner(a.ownerId).name.localeCompare(getOwner(b.ownerId).name)
    })

  return (
    <div className="flex h-full flex-col border-r border-border">
      <div className="flex items-center gap-2 border-b border-border p-3">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search accounts..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-8 pl-8 text-xs"
          />
        </div>
        <button
          onClick={() =>
            setSortBy(sortBy === "name" ? "activity" : sortBy === "activity" ? "owner" : "name")
          }
          className="flex items-center gap-1 rounded-md border border-border px-2 py-1.5 text-[10px] text-muted-foreground hover:bg-secondary"
        >
          <ArrowUpDown className="size-3" />
          {sortBy}
        </button>
      </div>
      <ScrollArea className="flex-1">
        <div className="flex flex-col">
          {filtered.map((company) => (
            <button
              key={company.id}
              onClick={() => onSelect(company.id)}
              className={cn(
                "flex items-center gap-3 border-b border-border px-3 py-2.5 text-left transition-colors",
                selected === company.id ? "bg-accent" : "hover:bg-secondary/50"
              )}
            >
              <div className={cn("size-2 shrink-0 rounded-full", getHealthColor(company.ownershipHealth))} />
              <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                <div className="flex items-center gap-1.5">
                  <span className="truncate text-sm font-medium text-foreground">{company.name}</span>
                  {company.isStrategic && <Star className="size-3 shrink-0 fill-warning text-warning" />}
                </div>
                <span className="text-[11px] text-muted-foreground">{company.industry}</span>
              </div>
              <div className="flex shrink-0 items-center gap-2">
                <OwnerAvatar ownerId={company.ownerId} />
                <div className="flex flex-col items-end gap-0.5">
                  <Badge variant="outline" className="h-4 px-1 text-[10px]">
                    <Users className="mr-0.5 size-2.5" />
                    {company.contacts.length}
                  </Badge>
                  <Badge variant="secondary" className="h-4 px-1 text-[10px]">
                    {company.openRequisitions} open
                  </Badge>
                </div>
              </div>
            </button>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

/* ── Company detail (right panel) ─────────────────────── */

function CompanyDetail({ companyId }: { companyId: string }) {
  const company = companies.find((c) => c.id === companyId)
  const [expandedSites, setExpandedSites] = useState<string[]>([])
  const [noteText, setNoteText] = useState("")
  const [activityFilter, setActivityFilter] = useState<string | null>(null)
  const [contactSearch, setContactSearch] = useState("")
  const [contactSiteFilter, setContactSiteFilter] = useState<string | null>(null)
  const [contactStatusFilter, setContactStatusFilter] = useState<ContactStatus | null>(null)
  const [expandedContact, setExpandedContact] = useState<string | null>(null)
  const [selectedReq, setSelectedReq] = useState<string | null>(null)
  const [pipelineContactFilter, setPipelineContactFilter] = useState<string | null>(null)
  const [contactStatuses, setContactStatuses] = useState<Record<string, ContactStatus>>({})

  const getStatus = (contactId: string, original: ContactStatus): ContactStatus =>
    contactStatuses[contactId] ?? original

  const setStatus = (contactId: string, newStatus: ContactStatus) =>
    setContactStatuses((prev) => ({ ...prev, [contactId]: newStatus }))

  const handleEmailClick = useCallback((contactName: string, email: string) => {
    window.location.href = `mailto:${email}`
    console.log(`[Activity Created] email_sent to ${contactName} (${email})`)
  }, [])

  const handlePhoneClick = useCallback((contactName: string, phone: string) => {
    const cleanNumber = phone.replace(/[^+\d]/g, "")
    window.location.href = `tel:${cleanNumber}`
    console.log(`[Activity Created] phone call to ${contactName} (${phone})`)
  }, [])

  if (!company) {
    return (
      <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
        Select an account to view details
      </div>
    )
  }

  const owner = getOwner(company.ownerId)
  const toggleSite = (siteId: string) =>
    setExpandedSites((prev) =>
      prev.includes(siteId) ? prev.filter((s) => s !== siteId) : [...prev, siteId]
    )

  const statusCounts = {
    open: company.requisitions.filter((r) => r.status === "open").length,
    quoted: company.requisitions.filter((r) => r.status === "quoted").length,
    won: company.requisitions.filter((r) => r.status === "won").length,
    lost: company.requisitions.filter((r) => r.status === "lost").length,
  }

  // Filter activities by contact
  const filteredActivities = activityFilter
    ? company.activities.filter((a) => a.contactId === activityFilter)
    : company.activities

  const activeContact = activityFilter
    ? company.contacts.find((c) => c.id === activityFilter)
    : null

  // Filter contacts by search, site, and status
  const filteredContacts = company.contacts.filter((c) => {
    if (contactSearch && !c.name.toLowerCase().includes(contactSearch.toLowerCase()) && !c.title.toLowerCase().includes(contactSearch.toLowerCase()) && !c.email.toLowerCase().includes(contactSearch.toLowerCase())) return false
    if (contactSiteFilter && c.siteId !== contactSiteFilter) return false
    if (contactStatusFilter && getStatus(c.id, c.status) !== contactStatusFilter) return false
    return true
  }).sort((a, b) => {
    const aIdx = STATUS_ORDER.indexOf(getStatus(a.id, a.status))
    const bIdx = STATUS_ORDER.indexOf(getStatus(b.id, b.status))
    return aIdx - bIdx
  })

  // Contacts that have requisitions linked to them (for pipeline filter)
  const contactsWithReqs = useMemo(() => {
    const ids = new Set(company.requisitions.map((r) => r.contactId).filter(Boolean))
    return company.contacts.filter((c) => ids.has(c.id))
  }, [company.contacts, company.requisitions])

  // Filtered requisitions for pipeline tab
  const filteredRequisitions = pipelineContactFilter
    ? company.requisitions.filter((r) => r.contactId === pipelineContactFilter)
    : company.requisitions

  return (
    <ScrollArea className="h-full">
      <div className="flex flex-col gap-4 p-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold text-foreground">{company.name}</h2>
              {company.isStrategic && <Star className="size-4 fill-warning text-warning" />}
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span>{company.industry}</span>
              <span>Owner: {owner.name}</span>
              <span>{company.contacts.length} contacts</span>
              <span>{company.siteCount} sites</span>
            </div>
          </div>
        </div>

        {/* Notes */}
        <div className="rounded-md border border-border bg-card p-3">
          <label htmlFor="account-notes" className="mb-1.5 block text-xs font-medium text-foreground">
            Notes
          </label>
          <textarea
            id="account-notes"
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            placeholder="Add a note about this account..."
            className="h-16 w-full resize-none rounded-md border border-border bg-background px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring"
          />
        </div>

        {/* Relationship Health + Contact Qualification side by side */}
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-md border border-border bg-card p-3">
            <RelationshipHealthBar company={company} />
          </div>
          <div className="rounded-md border border-border bg-card p-3">
            <ContactStatusSummary company={company} statusOverrides={contactStatuses} />
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="contacts" className="flex-1">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="contacts" className="text-xs">
              <Users className="mr-1 size-3" />
              Contacts ({company.contacts.length})
            </TabsTrigger>
            <TabsTrigger value="sites" className="text-xs">
              <MapPin className="mr-1 size-3" />
              Sites ({company.siteCount})
            </TabsTrigger>
            <TabsTrigger value="activity" className="text-xs">
              Activity
            </TabsTrigger>
            <TabsTrigger value="pipeline" className="text-xs">
              Pipeline ({company.requisitions.length})
            </TabsTrigger>
          </TabsList>

          {/* ─── Contacts Tab (primary — scales to 50+) ──────── */}
          <TabsContent value="contacts">
            <div className="flex flex-col gap-3">
              {/* Search + filters row */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-2 top-1/2 size-3 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search contacts by name, title, email..."
                    value={contactSearch}
                    onChange={(e) => setContactSearch(e.target.value)}
                    className="h-7 pl-7 text-[11px]"
                  />
                </div>
              </div>

              {/* Filter chips: site + status */}
              <div className="flex flex-wrap items-center gap-1.5">
                <Filter className="size-3 text-muted-foreground" />

                {/* Site filter chips */}
                <button
                  onClick={() => setContactSiteFilter(null)}
                  className={cn(
                    "rounded-full px-2 py-0.5 text-[10px] font-medium transition-colors",
                    !contactSiteFilter
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  )}
                >
                  All Sites
                </button>
                {company.sites.map((site) => {
                  const shortAddr = site.address.split(",")[0]
                  const count = company.contacts.filter((c) => c.siteId === site.id).length
                  return (
                    <button
                      key={site.id}
                      onClick={() =>
                        setContactSiteFilter(contactSiteFilter === site.id ? null : site.id)
                      }
                      className={cn(
                        "rounded-full px-2 py-0.5 text-[10px] font-medium transition-colors",
                        contactSiteFilter === site.id
                          ? "bg-primary text-primary-foreground"
                          : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                      )}
                    >
                      {shortAddr} ({count})
                    </button>
                  )
                })}

                <span className="mx-1 text-border">|</span>

                {/* Status filter chips */}
                <button
                  onClick={() => setContactStatusFilter(null)}
                  className={cn(
                    "rounded-full px-2 py-0.5 text-[10px] font-medium transition-colors",
                    !contactStatusFilter
                      ? "bg-foreground text-background"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  )}
                >
                  All Status
                </button>
                {STATUS_ORDER.map((status) => {
                  const config = STATUS_CONFIG[status]
                  const count = company.contacts.filter(
                    (c) => getStatus(c.id, c.status) === status
                  ).length
                  if (count === 0) return null
                  return (
                    <button
                      key={status}
                      onClick={() =>
                        setContactStatusFilter(contactStatusFilter === status ? null : status)
                      }
                      className={cn(
                        "rounded-full px-2 py-0.5 text-[10px] font-medium transition-colors",
                        contactStatusFilter === status
                          ? cn(config.bg, config.color, "ring-1 ring-current")
                          : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                      )}
                    >
                      {config.label} ({count})
                    </button>
                  )
                })}
              </div>

              {/* Results count */}
              <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                <span>
                  Showing {filteredContacts.length} of {company.contacts.length} contacts
                </span>
              </div>

              {/* Contact rows — compact for scale */}
              <div className="flex flex-col rounded-md border border-border">
                {filteredContacts.length === 0 && (
                  <div className="px-3 py-6 text-center text-xs text-muted-foreground">
                    No contacts match your filters
                  </div>
                )}
                {filteredContacts.map((contact, i) => {
                  const site = company.sites.find((s) => s.id === contact.siteId)
                  const isExpanded = expandedContact === contact.id
                  const contactActivities = company.activities.filter(
                    (a) => a.contactId === contact.id
                  )

                  return (
                    <div
                      key={contact.id}
                      className={cn(
                        "border-b border-border last:border-0",
                        i % 2 === 0 ? "bg-card" : "bg-secondary/20"
                      )}
                    >
                      {/* Compact row */}
                      <div className="flex items-center gap-2 px-3 py-2">
                        <button
                          onClick={() => setExpandedContact(isExpanded ? null : contact.id)}
                          className="shrink-0"
                          aria-label={isExpanded ? "Collapse contact" : "Expand contact"}
                        >
                          {isExpanded ? (
                            <ChevronDown className="size-3 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="size-3 text-muted-foreground" />
                          )}
                        </button>

                        <div className={cn("size-1.5 shrink-0 rounded-full", getContactHealthColor(contact.lastContacted))} />

                        <div className="flex min-w-0 flex-1 items-center gap-2">
                          <span className="shrink-0 text-xs font-medium text-foreground">
                            {contact.name}
                          </span>
                          {contact.aiEnriched && (
                            <Sparkles className="size-2.5 shrink-0 text-primary" />
                          )}
                          <span className="truncate text-[11px] text-muted-foreground">
                            {contact.title}
                          </span>
                        </div>

                        {/* Clickable status — cycles to next on click */}
                        {(() => {
                          const current = getStatus(contact.id, contact.status)
                          const config = STATUS_CONFIG[current]
                          const Icon = config.icon
                          const nextIdx = (STATUS_ORDER.indexOf(current) + 1) % STATUS_ORDER.length
                          return (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    setStatus(contact.id, STATUS_ORDER[nextIdx])
                                  }}
                                  className={cn(
                                    "flex shrink-0 cursor-pointer items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-medium transition-all hover:opacity-80 active:scale-95",
                                    config.bg,
                                    config.color
                                  )}
                                  aria-label={`Status: ${config.label}. Click to change.`}
                                >
                                  <Icon className="size-2.5" />
                                  {config.label}
                                </button>
                              </TooltipTrigger>
                              <TooltipContent side="top" className="text-xs">
                                Click to change to {STATUS_CONFIG[STATUS_ORDER[nextIdx]].label}
                              </TooltipContent>
                            </Tooltip>
                          )
                        })()}

                        {/* Site pill */}
                        {site && (
                          <span className="hidden shrink-0 rounded-full bg-secondary px-1.5 py-0.5 text-[9px] text-muted-foreground lg:inline">
                            {site.address.split(",")[0]}
                          </span>
                        )}

                        {/* Contact actions */}
                        <div className="flex shrink-0 items-center gap-1">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <a
                                href={`mailto:${contact.email}`}
                                onClick={(e) => {
                                  e.preventDefault()
                                  handleEmailClick(contact.name, contact.email)
                                }}
                                className="flex size-6 items-center justify-center rounded text-primary transition-colors hover:bg-accent"
                                aria-label={`Email ${contact.name}`}
                              >
                                <Mail className="size-3" />
                              </a>
                            </TooltipTrigger>
                            <TooltipContent>{contact.email}</TooltipContent>
                          </Tooltip>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <a
                                href={`tel:${contact.phone.replace(/[^+\d]/g, "")}`}
                                onClick={(e) => {
                                  e.preventDefault()
                                  handlePhoneClick(contact.name, contact.phone)
                                }}
                                className="flex size-6 items-center justify-center rounded text-chart-2 transition-colors hover:bg-accent"
                                aria-label={`Call ${contact.name}`}
                              >
                                <Phone className="size-3" />
                              </a>
                            </TooltipTrigger>
                            <TooltipContent>{contact.phone}</TooltipContent>
                          </Tooltip>
                        </div>

                        <span className="shrink-0 text-[10px] text-muted-foreground">
                          {getContactHealthLabel(contact.lastContacted)}
                        </span>
                      </div>

                      {/* Expanded detail */}
                      {isExpanded && (
                        <div className="border-t border-border bg-accent/30 px-4 py-3">
                          <div className="grid grid-cols-2 gap-4">
                            {/* Left: info */}
                            <div className="flex flex-col gap-2">
                              <div className="flex flex-col gap-1">
                                <span className="text-[10px] font-medium text-muted-foreground uppercase">Details</span>
                                {contact.department && (
                                  <span className="text-xs text-foreground">Dept: {contact.department}</span>
                                )}
                                <a
                                  href={`mailto:${contact.email}`}
                                  onClick={(e) => {
                                    e.preventDefault()
                                    handleEmailClick(contact.name, contact.email)
                                  }}
                                  className="text-xs text-primary underline-offset-2 hover:underline"
                                >
                                  {contact.email}
                                </a>
                                <a
                                  href={`tel:${contact.phone.replace(/[^+\d]/g, "")}`}
                                  onClick={(e) => {
                                    e.preventDefault()
                                    handlePhoneClick(contact.name, contact.phone)
                                  }}
                                  className="text-xs text-chart-2 underline-offset-2 hover:underline"
                                >
                                  {contact.phone}
                                </a>
                                {site && (
                                  <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                                    <MapPin className="size-2.5" />
                                    {site.address}
                                  </span>
                                )}
                              </div>
                              {/* Qualification buttons */}
                              <div className="flex flex-col gap-1.5">
                                <span className="text-[10px] font-medium uppercase text-muted-foreground">
                                  Qualification
                                </span>
                                <div className="flex flex-wrap items-center gap-1">
                                  {STATUS_ORDER.map((s) => {
                                    const sc = STATUS_CONFIG[s]
                                    const SIcon = sc.icon
                                    const isActive = getStatus(contact.id, contact.status) === s
                                    return (
                                      <button
                                        key={s}
                                        onClick={() => setStatus(contact.id, s)}
                                        className={cn(
                                          "flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-medium transition-all",
                                          isActive
                                            ? cn(sc.bg, sc.color, "border-current")
                                            : "border-border bg-card text-muted-foreground hover:border-muted-foreground/50"
                                        )}
                                      >
                                        <SIcon className="size-2.5" />
                                        {sc.label}
                                      </button>
                                    )
                                  })}
                                </div>
                              </div>
                              <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                                <span>Source: {contact.source.replace("_", " ")}</span>
                                <span>Outreach: {contact.outreachAttempts ?? 0}x</span>
                              </div>
                              {contact.notes && (
                                <div className="rounded-md bg-warning/10 px-2 py-1.5 text-[11px] text-foreground">
                                  {contact.notes}
                                </div>
                              )}
                            </div>

                            {/* Right: recent activity for this contact */}
                            <div className="flex flex-col gap-1.5">
                              <span className="text-[10px] font-medium text-muted-foreground uppercase">
                                Recent Activity ({contactActivities.length})
                              </span>
                              {contactActivities.length === 0 ? (
                                <span className="text-[11px] text-muted-foreground">
                                  No activity recorded
                                </span>
                              ) : (
                                contactActivities.slice(0, 4).map((a) => (
                                  <div key={a.id} className="flex items-start gap-2">
                                    <ActivityIcon type={a.type} />
                                    <div className="flex flex-col">
                                      <span className="text-[11px] leading-relaxed text-foreground">
                                        {a.summary.length > 60 ? a.summary.slice(0, 60) + "..." : a.summary}
                                      </span>
                                      <span className="text-[10px] text-muted-foreground">
                                        {getRelativeTime(a.timestamp)}
                                      </span>
                                    </div>
                                  </div>
                                ))
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </div>
          </TabsContent>

          {/* ─── Sites Tab (grouped by site with contacts) ── */}
          <TabsContent value="sites">
            <div className="flex flex-col gap-1">
              {company.sites.map((site) => {
                const siteContacts = company.contacts.filter((c) => c.siteId === site.id)
                const isExpanded = expandedSites.includes(site.id)
                // Group contacts by status
                const byStatus = STATUS_ORDER.filter((s) =>
                  siteContacts.some((c) => getStatus(c.id, c.status) === s)
                )

                return (
                  <div key={site.id} className="rounded-md border border-border">
                    <button
                      onClick={() => toggleSite(site.id)}
                      className="flex w-full items-center gap-2 px-3 py-2.5 text-left"
                    >
                      {isExpanded ? (
                        <ChevronDown className="size-3.5 text-muted-foreground" />
                      ) : (
                        <ChevronRight className="size-3.5 text-muted-foreground" />
                      )}
                      <MapPin className="size-3 text-primary" />
                      <span className="flex-1 text-xs font-medium text-foreground">{site.address}</span>
                      <Badge variant="outline" className="h-4 px-1 text-[10px]">
                        {siteContacts.length} contact{siteContacts.length !== 1 && "s"}
                      </Badge>
                    </button>
                    {isExpanded && (
                      <div className="border-t border-border bg-secondary/30 px-3 py-2">
                        <div className="mb-2 text-[10px] text-muted-foreground">
                          Last RFQ: {site.lastRequisitionDate}
                        </div>
                        {byStatus.map((status) => {
                          const contacts = siteContacts.filter(
                            (c) => getStatus(c.id, c.status) === status
                          )
                          return (
                            <div key={status} className="mb-2">
                              <div className="mb-1 flex items-center gap-1">
                                <StatusBadge status={status} compact />
                                <span className="text-[10px] text-muted-foreground">
                                  ({contacts.length})
                                </span>
                              </div>
                              <div className="flex flex-col gap-1 pl-2">
                                {contacts.map((contact) => (
                                  <div
                                    key={contact.id}
                                    className="flex items-center justify-between rounded-md bg-card px-2 py-1.5"
                                  >
                                    <div className="flex items-center gap-1.5">
                                      <div className={cn("size-1.5 rounded-full", getContactHealthColor(contact.lastContacted))} />
                                      <span className="text-[11px] font-medium text-foreground">
                                        {contact.name}
                                      </span>
                                      {contact.aiEnriched && <Sparkles className="size-2.5 text-primary" />}
                                      <span className="text-[10px] text-muted-foreground">
                                        {contact.title}
                                      </span>
                                    </div>
                                    <div className="flex items-center gap-1">
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <a
                                            href={`mailto:${contact.email}`}
                                            onClick={(e) => {
                                              e.preventDefault()
                                              handleEmailClick(contact.name, contact.email)
                                            }}
                                            className="flex size-6 items-center justify-center rounded text-primary hover:bg-accent"
                                            aria-label={`Email ${contact.name}`}
                                          >
                                            <Mail className="size-3" />
                                          </a>
                                        </TooltipTrigger>
                                        <TooltipContent>{contact.email}</TooltipContent>
                                      </Tooltip>
                                      <Tooltip>
                                        <TooltipTrigger asChild>
                                          <a
                                            href={`tel:${contact.phone.replace(/[^+\d]/g, "")}`}
                                            onClick={(e) => {
                                              e.preventDefault()
                                              handlePhoneClick(contact.name, contact.phone)
                                            }}
                                            className="flex size-6 items-center justify-center rounded text-chart-2 hover:bg-accent"
                                            aria-label={`Call ${contact.name}`}
                                          >
                                            <Phone className="size-3" />
                                          </a>
                                        </TooltipTrigger>
                                        <TooltipContent>{contact.phone}</TooltipContent>
                                      </Tooltip>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )
                        })}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </TabsContent>

          {/* ─── Activity Timeline ──────────────────────── */}
          <TabsContent value="activity">
            {/* Contact filter chips */}
            <div className="mb-3 flex flex-wrap items-center gap-1.5">
              <button
                onClick={() => setActivityFilter(null)}
                className={cn(
                  "rounded-full px-2.5 py-1 text-[11px] font-medium transition-colors",
                  !activityFilter
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                )}
              >
                All
              </button>
              {company.contacts
                .filter((c) => company.activities.some((a) => a.contactId === c.id))
                .map((contact) => (
                  <button
                    key={contact.id}
                    onClick={() =>
                      setActivityFilter(activityFilter === contact.id ? null : contact.id)
                    }
                    className={cn(
                      "rounded-full px-2.5 py-1 text-[11px] font-medium transition-colors",
                      activityFilter === contact.id
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                    )}
                  >
                    {contact.name.split(" ")[0]}
                  </button>
                ))}
            </div>

            {activeContact && (
              <p className="mb-2 text-[11px] text-muted-foreground">
                Showing activity for {activeContact.name}
              </p>
            )}

            <div className="flex flex-col">
              {filteredActivities.length === 0 && (
                <p className="py-4 text-center text-xs text-muted-foreground">
                  No activity recorded{activeContact ? ` for ${activeContact.name}` : ""}
                </p>
              )}
              {filteredActivities.map((activity) => {
                const actContact = activity.contactId ? getContactById(activity.contactId) : null
                return (
                  <div
                    key={activity.id}
                    className="flex items-start gap-3 border-b border-border py-3 last:border-0"
                  >
                    <div className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-full bg-secondary">
                      <ActivityIcon type={activity.type} />
                    </div>
                    <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                      <p className="text-xs leading-relaxed text-foreground">{activity.summary}</p>
                      <div className="flex items-center gap-2">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <span className="text-[10px] text-muted-foreground">
                              {getRelativeTime(activity.timestamp)}
                            </span>
                          </TooltipTrigger>
                          <TooltipContent>
                            {new Date(activity.timestamp).toLocaleString()}
                          </TooltipContent>
                        </Tooltip>
                        <span className="text-[10px] text-muted-foreground">
                          {activity.userInitials}
                        </span>
                        {actContact && (
                          <span className="flex items-center gap-0.5 text-[10px] text-primary">
                            <User className="size-2.5" />
                            {actContact.name.split(" ")[0]}
                          </span>
                        )}
                        <SourceTag source={activity.source} />
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </TabsContent>

          {/* ─── Pipeline ──────────────────────────────── */}
          <TabsContent value="pipeline">
            <div className="flex flex-col gap-3">
              {/* Contact filter + summary row */}
              <div className="flex items-center gap-3">
                <select
                  value={pipelineContactFilter ?? ""}
                  onChange={(e) => setPipelineContactFilter(e.target.value || null)}
                  className="h-7 rounded-md border border-border bg-card px-2 text-xs text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
                >
                  <option value="">All Contacts ({company.requisitions.length})</option>
                  {contactsWithReqs.map((c) => {
                    const count = company.requisitions.filter((r) => r.contactId === c.id).length
                    return (
                      <option key={c.id} value={c.id}>
                        {c.name} ({count})
                      </option>
                    )
                  })}
                </select>
                <div className="flex items-center gap-2">
                  {(["open", "quoted", "won", "lost"] as const).map((status) => {
                    const colors = {
                      open: "bg-chart-3 text-card",
                      quoted: "bg-chart-2 text-card",
                      won: "bg-success text-success-foreground",
                      lost: "bg-destructive/80 text-card",
                    }
                    const count = filteredRequisitions.filter((r) => r.status === status).length
                    return (
                      <div
                        key={status}
                        className={cn(
                          "flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium",
                          colors[status]
                        )}
                      >
                        <span className="capitalize">{status}</span>
                        <span>{count}</span>
                      </div>
                    )
                  })}
                </div>
                <span className="ml-auto text-xs text-muted-foreground">
                  ${filteredRequisitions.reduce((s, r) => s + r.value, 0).toLocaleString()} total
                </span>
              </div>

              {/* Requisition table */}
              <div className="rounded-md border border-border">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-border bg-secondary/50">
                      <th className="px-3 py-2 text-left font-medium text-muted-foreground">Part #</th>
                      <th className="px-3 py-2 text-left font-medium text-muted-foreground">Contact</th>
                      <th className="px-3 py-2 text-right font-medium text-muted-foreground">Qty</th>
                      <th className="px-3 py-2 text-right font-medium text-muted-foreground">Value</th>
                      <th className="px-3 py-2 text-left font-medium text-muted-foreground">Status</th>
                      <th className="px-3 py-2 text-left font-medium text-muted-foreground">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredRequisitions.map((req, i) => {
                      const reqContact = req.contactId ? getContactById(req.contactId) : null
                      const isSelected = selectedReq === req.id
                      return (
                        <>
                          <tr
                            key={req.id}
                            className={cn(
                              "cursor-pointer transition-colors",
                              isSelected ? "bg-accent" : i % 2 === 0 ? "bg-card" : "bg-secondary/30",
                              "hover:bg-accent/70"
                            )}
                            onClick={() => setSelectedReq(isSelected ? null : req.id)}
                          >
                            <td className="px-3 py-2">
                              <button
                                className="font-mono text-primary underline-offset-2 hover:underline"
                                onClick={(e) => {
                                  e.stopPropagation()
                                  setSelectedReq(isSelected ? null : req.id)
                                }}
                              >
                                {req.partNumber}
                              </button>
                            </td>
                            <td className="px-3 py-2 text-muted-foreground">
                              {reqContact ? (
                                <span className="flex items-center gap-1">
                                  <User className="size-2.5 text-primary" />
                                  {reqContact.name}
                                </span>
                              ) : (
                                "-"
                              )}
                            </td>
                            <td className="px-3 py-2 text-right text-muted-foreground">
                              {req.quantity.toLocaleString()}
                            </td>
                            <td className="px-3 py-2 text-right font-medium text-foreground">
                              ${req.value.toLocaleString()}
                            </td>
                            <td className="px-3 py-2">
                              <span
                                className={cn(
                                  "inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[10px] font-medium",
                                  req.status === "open" && "bg-chart-3/10 text-chart-3",
                                  req.status === "quoted" && "bg-chart-2/10 text-chart-2",
                                  req.status === "won" && "bg-success/10 text-success",
                                  req.status === "lost" && "bg-destructive/10 text-destructive"
                                )}
                              >
                                <div
                                  className={cn(
                                    "size-1.5 rounded-full",
                                    req.status === "open" && "bg-chart-3",
                                    req.status === "quoted" && "bg-chart-2",
                                    req.status === "won" && "bg-success",
                                    req.status === "lost" && "bg-destructive"
                                  )}
                                />
                                {req.status}
                              </span>
                            </td>
                            <td className="px-3 py-2 text-muted-foreground">{req.dateCreated}</td>
                          </tr>
                          {/* Expanded requisition detail */}
                          {isSelected && (
                            <tr key={`${req.id}-detail`}>
                              <td colSpan={6} className="border-t border-border bg-accent/40 px-4 py-3">
                                <div className="flex gap-6">
                                  <div className="flex flex-col gap-1.5">
                                    <span className="text-[10px] font-medium uppercase text-muted-foreground">
                                      Requisition Detail
                                    </span>
                                    <div className="text-xs text-foreground">
                                      <span className="font-mono font-medium">{req.partNumber}</span>
                                      {" x "}{req.quantity.toLocaleString()} units
                                    </div>
                                    <div className="text-xs text-foreground">
                                      Value: <span className="font-medium">${req.value.toLocaleString()}</span>
                                      {" | "}Per unit: ${(req.value / req.quantity).toFixed(2)}
                                    </div>
                                    <div className="text-xs text-muted-foreground">
                                      Created: {req.dateCreated}
                                    </div>
                                  </div>
                                  {reqContact && (
                                    <div className="flex flex-col gap-1.5">
                                      <span className="text-[10px] font-medium uppercase text-muted-foreground">
                                        Contact
                                      </span>
                                      <span className="text-xs font-medium text-foreground">
                                        {reqContact.name}
                                      </span>
                                      <span className="text-xs text-muted-foreground">{reqContact.title}</span>
                                      <a
                                        href={`mailto:${reqContact.email}`}
                                        onClick={(e) => {
                                          e.preventDefault()
                                          handleEmailClick(reqContact.name, reqContact.email)
                                        }}
                                        className="text-xs text-primary hover:underline"
                                      >
                                        {reqContact.email}
                                      </a>
                                      <a
                                        href={`tel:${reqContact.phone.replace(/[^+\d]/g, "")}`}
                                        onClick={(e) => {
                                          e.preventDefault()
                                          handlePhoneClick(reqContact.name, reqContact.phone)
                                        }}
                                        className="text-xs text-chart-2 hover:underline"
                                      >
                                        {reqContact.phone}
                                      </a>
                                    </div>
                                  )}
                                  <div className="flex flex-col gap-1.5">
                                    <span className="text-[10px] font-medium uppercase text-muted-foreground">
                                      Related Activity
                                    </span>
                                    {company.activities
                                      .filter((a) => a.summary.toLowerCase().includes(req.partNumber.toLowerCase().slice(0, 6)) || (reqContact && a.contactId === reqContact.id))
                                      .slice(0, 3)
                                      .map((a) => (
                                        <div key={a.id} className="flex items-start gap-1.5">
                                          <ActivityIcon type={a.type} />
                                          <span className="text-[11px] text-foreground">
                                            {a.summary.length > 50 ? a.summary.slice(0, 50) + "..." : a.summary}
                                          </span>
                                        </div>
                                      ))}
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </ScrollArea>
  )
}

/* ── Main export ───────────────────────────────────────── */

export function AccountMap() {
  const [selectedCompany, setSelectedCompany] = useState(companies[0].id)

  return (
    <div className="flex h-full">
      <div className="w-[40%]">
        <CompanyList selected={selectedCompany} onSelect={setSelectedCompany} />
      </div>
      <div className="flex-1">
        <CompanyDetail companyId={selectedCompany} />
      </div>
    </div>
  )
}
