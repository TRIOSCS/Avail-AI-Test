"use client"

import { cn } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  AlertTriangle,
  BarChart3,
  Trophy,
  Radio,
  LinkIcon,
  Sparkles,
  Phone,
} from "lucide-react"
import { companies, vendors, owners, getOwner } from "@/lib/crm-data"

function DashboardCard({
  title,
  icon: Icon,
  children,
}: {
  title: string
  icon: React.ElementType
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-col rounded-md border border-border bg-card">
      <div className="flex items-center gap-2 border-b border-border px-4 py-2.5">
        <Icon className="size-3.5 text-muted-foreground" />
        <h3 className="text-xs font-semibold text-foreground">{title}</h3>
      </div>
      <div className="flex-1 p-4">{children}</div>
    </div>
  )
}

function OwnershipAlerts() {
  const expiring = companies
    .filter((c) => c.daysUntilExpiry <= 7)
    .sort((a, b) => a.daysUntilExpiry - b.daysUntilExpiry)

  return (
    <DashboardCard title="Ownership Alerts" icon={AlertTriangle}>
      {expiring.length === 0 ? (
        <p className="text-xs text-muted-foreground">No accounts expiring this week</p>
      ) : (
        <div className="flex flex-col gap-2">
          {expiring.map((company) => {
            const owner = getOwner(company.ownerId)
            const isUrgent = company.daysUntilExpiry <= 3
            return (
              <div
                key={company.id}
                className={cn(
                  "flex items-center justify-between rounded-md px-3 py-2 text-xs",
                  isUrgent ? "bg-destructive/10" : "bg-secondary/50"
                )}
              >
                <div className="flex flex-col gap-0.5">
                  <span className={cn("font-medium", isUrgent ? "text-destructive" : "text-foreground")}>
                    {company.name}
                  </span>
                  <span className="text-[10px] text-muted-foreground">{owner.name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={cn(
                      "font-mono text-xs font-semibold",
                      isUrgent ? "text-destructive" : "text-warning"
                    )}
                  >
                    {company.daysUntilExpiry}d
                  </span>
                  <button className="rounded bg-primary px-2 py-1 text-[10px] font-medium text-primary-foreground hover:bg-primary/90">
                    Log Activity
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </DashboardCard>
  )
}

function PipelineSummary() {
  const allReqs = companies.flatMap((c) => c.requisitions)
  const counts = {
    open: allReqs.filter((r) => r.status === "open").length,
    quoted: allReqs.filter((r) => r.status === "quoted").length,
    won: allReqs.filter((r) => r.status === "won").length,
    lost: allReqs.filter((r) => r.status === "lost").length,
  }
  const total = allReqs.reduce((sum, r) => sum + r.value, 0)
  const totalCount = allReqs.length

  const segments = [
    { key: "open", count: counts.open, color: "bg-chart-3", label: "Open" },
    { key: "quoted", count: counts.quoted, color: "bg-chart-2", label: "Quoted" },
    { key: "won", count: counts.won, color: "bg-success", label: "Won" },
    { key: "lost", count: counts.lost, color: "bg-destructive/70", label: "Lost" },
  ]

  return (
    <DashboardCard title="Pipeline Summary" icon={BarChart3}>
      <div className="flex flex-col gap-3">
        {/* Stacked bar */}
        <div className="flex h-6 w-full overflow-hidden rounded-md">
          {segments.map((seg) => (
            <div
              key={seg.key}
              className={cn("flex items-center justify-center text-[10px] font-medium text-card transition-all", seg.color)}
              style={{ width: `${(seg.count / totalCount) * 100}%` }}
            >
              {seg.count > 0 && seg.count}
            </div>
          ))}
        </div>
        {/* Legend */}
        <div className="flex items-center gap-4">
          {segments.map((seg) => (
            <div key={seg.key} className="flex items-center gap-1.5">
              <div className={cn("size-2 rounded-full", seg.color)} />
              <span className="text-[10px] text-muted-foreground">
                {seg.label} ({seg.count})
              </span>
            </div>
          ))}
        </div>
        <div className="border-t border-border pt-2">
          <span className="text-xs text-muted-foreground">Total Pipeline Value:</span>
          <span className="ml-2 text-sm font-semibold text-foreground">
            ${total.toLocaleString()}
          </span>
        </div>
      </div>
    </DashboardCard>
  )
}

function BuyerLeaderboard() {
  const buyerStats = owners.map((owner) => {
    const ownerCompanies = companies.filter((c) => c.ownerId === owner.id)
    const reqs = ownerCompanies.flatMap((c) => c.requisitions)
    const offers = reqs.length
    const wins = reqs.filter((r) => r.status === "won").length
    const winRate = offers > 0 ? Math.round((wins / offers) * 100) : 0

    return {
      ...owner,
      offers,
      winRate,
      avgResponseTime: `${Math.floor(Math.random() * 3) + 1}h`,
    }
  }).sort((a, b) => b.offers - a.offers)

  return (
    <DashboardCard title="Buyer Leaderboard" icon={Trophy}>
      <div className="flex flex-col gap-1.5">
        {buyerStats.map((buyer, i) => (
          <div
            key={buyer.id}
            className={cn(
              "flex items-center gap-3 rounded-md px-3 py-2 text-xs",
              i % 2 === 0 ? "bg-secondary/30" : ""
            )}
          >
            <span className="w-4 font-mono font-semibold text-muted-foreground">{i + 1}</span>
            <div className={cn("flex size-6 items-center justify-center rounded-full text-[10px] font-medium text-primary-foreground", buyer.color)}>
              {buyer.initials}
            </div>
            <span className="flex-1 font-medium text-foreground">{buyer.name}</span>
            <div className="flex items-center gap-4 text-muted-foreground">
              <span>{buyer.offers} offers</span>
              <span>{buyer.winRate}% win</span>
              <span>{buyer.avgResponseTime}</span>
            </div>
          </div>
        ))}
      </div>
    </DashboardCard>
  )
}

function VendorResponseRates() {
  const sorted = [...vendors]
    .filter((v) => !v.isColdStart)
    .sort((a, b) => b.responseRate - a.responseRate)

  return (
    <DashboardCard title="Vendor Response Rates" icon={Radio}>
      <div className="flex flex-col gap-1">
        {sorted.map((vendor, i) => {
          const color =
            vendor.responseRate >= 80
              ? "text-success"
              : vendor.responseRate >= 50
                ? "text-warning"
                : "text-destructive"
          return (
            <div
              key={vendor.id}
              className={cn(
                "flex items-center justify-between rounded-md px-3 py-1.5 text-xs",
                i % 2 === 0 ? "bg-secondary/30" : ""
              )}
            >
              <span className="font-medium text-foreground">{vendor.name}</span>
              <div className="flex items-center gap-2">
                <div className="h-1 w-20 overflow-hidden rounded-full bg-secondary">
                  <div
                    className={cn(
                      "h-full rounded-full",
                      vendor.responseRate >= 80
                        ? "bg-success"
                        : vendor.responseRate >= 50
                          ? "bg-warning"
                          : "bg-destructive"
                    )}
                    style={{ width: `${vendor.responseRate}%` }}
                  />
                </div>
                <span className={cn("w-8 text-right font-mono font-medium", color)}>
                  {vendor.responseRate}%
                </span>
              </div>
            </div>
          )
        })}
      </div>
    </DashboardCard>
  )
}

function UnmatchedActivities() {
  const unmatchedCount = 7
  return (
    <DashboardCard title="Unmatched Activities" icon={LinkIcon}>
      <div className="flex flex-col items-center gap-3 py-2 text-center">
        <div className="flex size-12 items-center justify-center rounded-full bg-warning/10">
          <span className="text-xl font-bold text-warning">{unmatchedCount}</span>
        </div>
        <p className="text-xs text-muted-foreground">
          Emails and calls not yet attributed to a customer
        </p>
        <button className="rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground hover:bg-primary/90">
          Review
        </button>
      </div>
    </DashboardCard>
  )
}

function AiInsights() {
  const insights = [
    "Rochester Electronics hasn't been contacted in 33 days but had 3 quoted RFQs last month — follow up?",
    "Honeywell Aerospace ownership expires in 3 days — 2 open quotes pending with $1,935 pipeline value.",
    "Arrow Electronics response velocity increased 12% this month — consider routing more STM32 RFQs.",
    "Flex Ltd ownership approaching expiry (9 days). Last activity was a stock update on TL431ACDR.",
  ]

  return (
    <DashboardCard title="AI Insights" icon={Sparkles}>
      <div className="flex flex-col gap-2">
        {insights.map((insight, i) => (
          <div key={i} className="flex items-start gap-2 rounded-md bg-accent/50 px-3 py-2">
            <Sparkles className="mt-0.5 size-3 shrink-0 text-primary" />
            <p className="text-xs text-foreground leading-relaxed">{insight}</p>
          </div>
        ))}
      </div>
    </DashboardCard>
  )
}

export function CrmDashboard() {
  return (
    <ScrollArea className="h-full">
      <div className="flex flex-col gap-4 p-4">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold text-foreground">Dashboard</h1>
          <span className="text-xs text-muted-foreground">Feb 22, 2026</span>
        </div>
        <div className="grid grid-cols-3 gap-4">
          <OwnershipAlerts />
          <PipelineSummary />
          <BuyerLeaderboard />
          <VendorResponseRates />
          <UnmatchedActivities />
          <AiInsights />
        </div>
      </div>
    </ScrollArea>
  )
}
