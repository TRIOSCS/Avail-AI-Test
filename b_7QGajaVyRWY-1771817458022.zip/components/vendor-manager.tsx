"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip"
import {
  Search,
  Mail,
  MailOpen,
  Phone,
  StickyNote,
  FileText,
  Tag,
  Sparkles,
  Loader2,
} from "lucide-react"
import {
  vendors,
  getRelativeTime,
  getEngagementStroke,
  type Vendor,
  type Activity,
} from "@/lib/crm-data"

function EngagementRing({ score, size = 36 }: { score: number; size?: number }) {
  const radius = (size - 6) / 2
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (score / 100) * circumference
  const stroke = getEngagementStroke(score)

  return (
    <svg width={size} height={size} className="shrink-0 -rotate-90">
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke="currentColor"
        strokeWidth={3}
        className="text-border"
      />
      <circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        fill="none"
        stroke={stroke}
        strokeWidth={3}
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        strokeLinecap="round"
      />
    </svg>
  )
}

function FactorBar({ label, value }: { label: string; value: number }) {
  const color =
    value >= 70 ? "bg-success" : value >= 40 ? "bg-warning" : "bg-destructive"
  return (
    <div className="flex items-center gap-3">
      <span className="w-40 text-xs text-muted-foreground">{label}</span>
      <div className="flex flex-1 items-center gap-2">
        <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-secondary">
          <div
            className={cn("h-full rounded-full transition-all", color)}
            style={{ width: `${value}%` }}
          />
        </div>
        <span className="w-7 text-right text-xs font-medium text-foreground">{value}</span>
      </div>
    </div>
  )
}

function ActivityIcon({ type }: { type: Activity["type"] }) {
  const classes = "size-3.5"
  switch (type) {
    case "email_sent":
      return <Mail className={cn(classes, "text-chart-3")} />
    case "email_received":
      return <MailOpen className={cn(classes, "text-primary")} />
    case "phone":
      return <Phone className={cn(classes, "text-chart-2")} />
    case "note":
      return <StickyNote className={cn(classes, "text-muted-foreground")} />
    case "quote":
      return <FileText className={cn(classes, "text-chart-4")} />
    case "offer":
      return <Tag className={cn(classes, "text-chart-5")} />
  }
}

function SourceTag({ source }: { source: Activity["source"] }) {
  const label = source === "graph_api" ? "via Graph API" : source === "8x8" ? "via 8x8" : "manual"
  return <span className="text-[10px] text-muted-foreground/70">{label}</span>
}

function RfqStatusDot({ status }: { status: string }) {
  const colorMap: Record<string, string> = {
    sent: "bg-chart-3",
    opened: "bg-chart-2",
    replied: "bg-primary",
    quoted: "bg-success",
    ghost: "bg-destructive",
  }
  return <div className={cn("size-2 rounded-full", colorMap[status] || "bg-muted-foreground")} />
}

function VendorList({
  selected,
  onSelect,
}: {
  selected: string
  onSelect: (id: string) => void
}) {
  const [search, setSearch] = useState("")

  const filtered = vendors
    .filter((v) => v.name.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => b.engagementScore - a.engagementScore)

  return (
    <div className="flex h-full flex-col border-r border-border">
      <div className="border-b border-border p-3">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search vendors..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-8 pl-8 text-xs"
          />
        </div>
      </div>
      <ScrollArea className="flex-1">
        <div className="flex flex-col">
          {filtered.map((vendor) => (
            <button
              key={vendor.id}
              onClick={() => onSelect(vendor.id)}
              className={cn(
                "flex items-center gap-3 border-b border-border px-3 py-2.5 text-left transition-colors",
                selected === vendor.id ? "bg-accent" : "hover:bg-secondary/50"
              )}
            >
              <EngagementRing score={vendor.engagementScore} size={32} />
              <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                <span className="truncate text-sm font-medium text-foreground">
                  {vendor.name}
                </span>
                <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                  <span>{vendor.responseRate}% response</span>
                  <span>{vendor.totalOffers} offers</span>
                </div>
              </div>
              <Tooltip>
                <TooltipTrigger asChild>
                  <span className="text-[10px] text-muted-foreground">
                    {getRelativeTime(vendor.lastInteraction)}
                  </span>
                </TooltipTrigger>
                <TooltipContent>
                  {new Date(vendor.lastInteraction).toLocaleString()}
                </TooltipContent>
              </Tooltip>
            </button>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}

function VendorDetail({ vendorId }: { vendorId: string }) {
  const vendor = vendors.find((v) => v.id === vendorId)

  if (!vendor) {
    return (
      <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
        Select a vendor to view details
      </div>
    )
  }

  return (
    <ScrollArea className="h-full">
      <div className="flex flex-col gap-4 p-4">
        {/* Header */}
        <div>
          <h2 className="text-lg font-semibold text-foreground">{vendor.name}</h2>
          <p className="text-xs text-muted-foreground">
            Last interaction: {getRelativeTime(vendor.lastInteraction)}
          </p>
        </div>

        {/* Engagement Score Card */}
        <div className="rounded-md border border-border bg-card p-4">
          <div className="flex items-center gap-6">
            <div className="relative flex items-center justify-center">
              {vendor.isColdStart ? (
                <div className="flex flex-col items-center gap-1">
                  <Loader2 className="size-10 animate-spin text-muted-foreground" />
                  <span className="text-[10px] text-muted-foreground">Building profile...</span>
                </div>
              ) : (
                <>
                  <EngagementRing score={vendor.engagementScore} size={72} />
                  <span className="absolute text-lg font-semibold text-foreground">
                    {vendor.engagementScore}
                  </span>
                </>
              )}
            </div>
            <div className="flex flex-1 flex-col gap-2">
              {!vendor.isColdStart ? (
                <>
                  <FactorBar label="Response Velocity" value={vendor.factors.responseVelocity} />
                  <FactorBar label="Ghost Rate" value={vendor.factors.ghostRate} />
                  <FactorBar label="Pricing Competitiveness" value={vendor.factors.pricingCompetitiveness} />
                  <FactorBar label="Volume Consistency" value={vendor.factors.volumeConsistency} />
                  <FactorBar label="Delivery Reliability" value={vendor.factors.deliveryReliability} />
                </>
              ) : (
                <div className="flex flex-col gap-2">
                  {["Response Velocity", "Ghost Rate", "Pricing", "Volume", "Delivery"].map((label) => (
                    <div key={label} className="flex items-center gap-3">
                      <span className="w-40 text-xs text-muted-foreground">{label}</span>
                      <div className="h-1.5 flex-1 animate-pulse rounded-full bg-secondary" />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="contacts" className="flex-1">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="contacts" className="text-xs">Contacts ({vendor.contacts.length})</TabsTrigger>
            <TabsTrigger value="parts" className="text-xs">Part History ({vendor.partHistory.length})</TabsTrigger>
            <TabsTrigger value="comms" className="text-xs">Communication</TabsTrigger>
            <TabsTrigger value="rfqs" className="text-xs">RFQ History ({vendor.rfqHistory.length})</TabsTrigger>
          </TabsList>

          {/* Contacts */}
          <TabsContent value="contacts">
            <div className="flex flex-col">
              {vendor.contacts.map((contact) => (
                <div
                  key={contact.id}
                  className="flex items-center justify-between border-b border-border py-2.5 last:border-0"
                >
                  <div className="flex flex-col gap-0.5">
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-medium text-foreground">{contact.name}</span>
                      {contact.isPrimary && (
                        <div className="size-1.5 rounded-full bg-primary" />
                      )}
                      {contact.autoDiscovered && (
                        <Sparkles className="size-3 text-primary" />
                      )}
                    </div>
                    <span className="text-[11px] text-muted-foreground">{contact.title}</span>
                  </div>
                  <div className="flex flex-col items-end gap-0.5 text-[11px] text-muted-foreground">
                    <span>{contact.email}</span>
                    <span>{contact.phone}</span>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* Part History */}
          <TabsContent value="parts">
            {vendor.partHistory.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-8 text-center">
                <p className="text-sm text-muted-foreground">No part history yet</p>
                <button className="rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground">
                  Send first RFQ
                </button>
              </div>
            ) : (
              <div className="rounded-md border border-border">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-border bg-secondary/50">
                      <th className="px-3 py-2 text-left font-medium text-muted-foreground">Part #</th>
                      <th className="px-3 py-2 text-left font-medium text-muted-foreground">Last Quoted</th>
                      <th className="px-3 py-2 text-right font-medium text-muted-foreground">Price</th>
                      <th className="px-3 py-2 text-right font-medium text-muted-foreground">Qty</th>
                      <th className="px-3 py-2 text-left font-medium text-muted-foreground">Lead Time</th>
                      <th className="px-3 py-2 text-left font-medium text-muted-foreground">Outcome</th>
                    </tr>
                  </thead>
                  <tbody>
                    {vendor.partHistory.map((part, i) => (
                      <tr key={part.partNumber} className={cn(i % 2 === 0 ? "bg-card" : "bg-secondary/30")}>
                        <td className="px-3 py-2 font-mono text-foreground">{part.partNumber}</td>
                        <td className="px-3 py-2 text-muted-foreground">{part.lastQuotedDate}</td>
                        <td className="px-3 py-2 text-right text-foreground">${part.lastPrice.toFixed(2)}</td>
                        <td className="px-3 py-2 text-right text-muted-foreground">{part.quantity.toLocaleString()}</td>
                        <td className="px-3 py-2 text-muted-foreground">{part.leadTime}</td>
                        <td className="px-3 py-2">
                          <div
                            className={cn(
                              "size-2 rounded-full",
                              part.outcome === "won" && "bg-success",
                              part.outcome === "lost" && "bg-destructive",
                              part.outcome === "pending" && "bg-chart-2"
                            )}
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </TabsContent>

          {/* Communication Log */}
          <TabsContent value="comms">
            <div className="flex flex-col">
              {vendor.activities.map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-start gap-3 border-b border-border py-3 last:border-0"
                >
                  <div className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-full bg-secondary">
                    <ActivityIcon type={activity.type} />
                  </div>
                  <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                    <p className="text-xs text-foreground leading-relaxed">{activity.summary}</p>
                    <div className="flex items-center gap-2">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className="text-[10px] text-muted-foreground">
                            {getRelativeTime(activity.timestamp)}
                          </span>
                        </TooltipTrigger>
                        <TooltipContent>
                          {new Date(activity.timestamp).toLocaleString()}
                        </TooltipContent>
                      </Tooltip>
                      <span className="text-[10px] text-muted-foreground">{activity.userInitials}</span>
                      <SourceTag source={activity.source} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          {/* RFQ History */}
          <TabsContent value="rfqs">
            <div className="rounded-md border border-border">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-border bg-secondary/50">
                    <th className="px-3 py-2 text-left font-medium text-muted-foreground">Part #</th>
                    <th className="px-3 py-2 text-left font-medium text-muted-foreground">Date Sent</th>
                    <th className="px-3 py-2 text-right font-medium text-muted-foreground">Qty</th>
                    <th className="px-3 py-2 text-left font-medium text-muted-foreground">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {vendor.rfqHistory.map((rfq, i) => (
                    <tr key={rfq.id} className={cn(i % 2 === 0 ? "bg-card" : "bg-secondary/30")}>
                      <td className="px-3 py-2 font-mono text-foreground">{rfq.partNumber}</td>
                      <td className="px-3 py-2 text-muted-foreground">{rfq.dateSent}</td>
                      <td className="px-3 py-2 text-right text-muted-foreground">{rfq.quantity.toLocaleString()}</td>
                      <td className="px-3 py-2">
                        <div className="flex items-center gap-1.5">
                          <RfqStatusDot status={rfq.status} />
                          <span className="capitalize text-muted-foreground">{rfq.status}</span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </ScrollArea>
  )
}

export function VendorManager() {
  const [selectedVendor, setSelectedVendor] = useState(vendors[0].id)

  return (
    <div className="flex h-full">
      <div className="w-[40%]">
        <VendorList selected={selectedVendor} onSelect={setSelectedVendor} />
      </div>
      <div className="flex-1">
        <VendorDetail vendorId={selectedVendor} />
      </div>
    </div>
  )
}
