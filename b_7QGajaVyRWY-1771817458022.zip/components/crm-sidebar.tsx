"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import {
  Building2,
  Users,
  GitBranch,
  Truck,
  LayoutDashboard,
  ChevronRight,
  Zap,
} from "lucide-react"
import { Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip"

type View = "accounts" | "contacts" | "pipeline" | "vendors" | "dashboard"

interface CrmSidebarProps {
  activeView: View
  onViewChange: (view: View) => void
}

const navItems: { id: View; label: string; icon: React.ElementType }[] = [
  { id: "accounts", label: "Accounts", icon: Building2 },
  { id: "contacts", label: "Contacts", icon: Users },
  { id: "pipeline", label: "Pipeline", icon: GitBranch },
  { id: "vendors", label: "Vendors", icon: Truck },
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
]

export function CrmSidebar({ activeView, onViewChange }: CrmSidebarProps) {
  const [expanded, setExpanded] = useState(false)

  return (
    <aside
      className={cn(
        "fixed left-0 top-0 z-40 flex h-screen flex-col bg-sidebar-bg text-sidebar-foreground transition-all duration-200",
        expanded ? "w-48" : "w-14"
      )}
    >
      <div className="flex h-12 items-center justify-center border-b border-sidebar-border px-3">
        {expanded ? (
          <div className="flex items-center gap-2">
            <Zap className="size-5 text-primary" />
            <span className="text-sm font-semibold tracking-wide text-sidebar-primary-foreground">
              AVAIL
            </span>
          </div>
        ) : (
          <Zap className="size-5 text-primary" />
        )}
      </div>

      <nav className="flex flex-1 flex-col gap-1 px-2 py-3">
        {navItems.map((item) => {
          const isActive = activeView === item.id
          const button = (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={cn(
                "flex w-full items-center gap-3 rounded-md px-2 py-2 text-sm transition-colors",
                isActive
                  ? "bg-sidebar-accent text-sidebar-primary-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground"
              )}
            >
              <item.icon className={cn("size-[18px] shrink-0", isActive && "text-primary")} />
              {expanded && <span>{item.label}</span>}
            </button>
          )

          if (!expanded) {
            return (
              <Tooltip key={item.id}>
                <TooltipTrigger asChild>{button}</TooltipTrigger>
                <TooltipContent side="right">{item.label}</TooltipContent>
              </Tooltip>
            )
          }

          return button
        })}
      </nav>

      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center justify-center border-t border-sidebar-border p-3 text-sidebar-foreground/60 hover:text-sidebar-foreground"
      >
        <ChevronRight
          className={cn(
            "size-4 transition-transform",
            expanded && "rotate-180"
          )}
        />
      </button>
    </aside>
  )
}
