"use client"

import { useState, useMemo } from "react"
import { cn } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"
import { User, ChevronDown, ChevronRight, Mail, Phone } from "lucide-react"
import {
  companies,
  getOwner,
  getContactById,
  type Requisition,
  type RequisitionStatus,
} from "@/lib/crm-data"

const columns: { status: RequisitionStatus; label: string; color: string; dotColor: string }[] = [
  { status: "open", label: "Open", color: "border-chart-3", dotColor: "bg-chart-3" },
  { status: "quoted", label: "Quoted", color: "border-chart-2", dotColor: "bg-chart-2" },
  { status: "won", label: "Won", color: "border-success", dotColor: "bg-success" },
  { status: "lost", label: "Lost", color: "border-destructive", dotColor: "bg-destructive" },
]

interface ReqWithCompany extends Requisition {
  companyName: string
  ownerId: string
}

export function PipelineView() {
  const [contactFilter, setContactFilter] = useState<string | null>(null)
  const [expandedReq, setExpandedReq] = useState<string | null>(null)

  const allReqs: ReqWithCompany[] = companies.flatMap((c) =>
    c.requisitions.map((r) => ({ ...r, companyName: c.name, ownerId: c.ownerId }))
  )

  // Get unique contacts who have requisitions
  const contactsWithReqs = useMemo(() => {
    const contactIds = new Set(allReqs.map((r) => r.contactId).filter(Boolean))
    const contacts: { id: string; name: string; count: number }[] = []
    for (const id of contactIds) {
      const contact = getContactById(id!)
      if (contact) {
        contacts.push({ id: contact.id, name: contact.name, count: allReqs.filter((r) => r.contactId === id).length })
      }
    }
    return contacts.sort((a, b) => b.count - a.count)
  }, [allReqs])

  const filteredReqs = contactFilter
    ? allReqs.filter((r) => r.contactId === contactFilter)
    : allReqs

  return (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <h1 className="text-lg font-semibold text-foreground">Pipeline</h1>
        <div className="flex items-center gap-3">
          <select
            value={contactFilter ?? ""}
            onChange={(e) => setContactFilter(e.target.value || null)}
            className="h-7 rounded-md border border-border bg-card px-2 text-xs text-foreground focus:outline-none focus:ring-1 focus:ring-ring"
          >
            <option value="">All Contacts ({allReqs.length})</option>
            {contactsWithReqs.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.count})
              </option>
            ))}
          </select>
          <span className="text-xs text-muted-foreground">
            {filteredReqs.length} requisitions | ${filteredReqs.reduce((s, r) => s + r.value, 0).toLocaleString()}
          </span>
        </div>
      </div>
      <div className="flex flex-1 gap-4 overflow-x-auto p-4">
        {columns.map((col) => {
          const reqs = filteredReqs.filter((r) => r.status === col.status)
          const totalValue = reqs.reduce((sum, r) => sum + r.value, 0)
          return (
            <div key={col.status} className="flex w-72 shrink-0 flex-col">
              <div
                className={cn(
                  "mb-3 flex items-center justify-between rounded-md border-l-2 bg-card px-3 py-2",
                  col.color
                )}
              >
                <div className="flex items-center gap-2">
                  <div className={cn("size-2 rounded-full", col.dotColor)} />
                  <span className="text-xs font-semibold text-foreground">{col.label}</span>
                  <span className="text-xs text-muted-foreground">({reqs.length})</span>
                </div>
                <span className="text-xs font-medium text-muted-foreground">
                  ${totalValue.toLocaleString()}
                </span>
              </div>
              <ScrollArea className="flex-1">
                <div className="flex flex-col gap-2">
                  {reqs.map((req) => {
                    const owner = getOwner(req.ownerId)
                    const contact = req.contactId ? getContactById(req.contactId) : null
                    const isExpanded = expandedReq === req.id
                    return (
                      <div key={req.id} className="rounded-md border border-border bg-card">
                        <button
                          className="flex w-full flex-col p-3 text-left"
                          onClick={() => setExpandedReq(isExpanded ? null : req.id)}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-1.5">
                              {isExpanded ? (
                                <ChevronDown className="size-3 text-muted-foreground" />
                              ) : (
                                <ChevronRight className="size-3 text-muted-foreground" />
                              )}
                              <span className="font-mono text-xs font-medium text-primary">
                                {req.partNumber}
                              </span>
                            </div>
                            <div
                              className={cn(
                                "flex size-5 items-center justify-center rounded-full text-[8px] font-medium text-primary-foreground",
                                owner.color
                              )}
                            >
                              {owner.initials}
                            </div>
                          </div>
                          <div className="mt-1.5 flex items-center justify-between text-[11px] text-muted-foreground">
                            <span>{req.companyName}</span>
                            <span>${req.value.toLocaleString()}</span>
                          </div>
                          {contact && (
                            <div className="mt-1 flex items-center gap-1 text-[10px] text-primary">
                              <User className="size-2.5" />
                              <span>{contact.name}</span>
                            </div>
                          )}
                          <div className="mt-1 flex items-center justify-between text-[10px] text-muted-foreground">
                            <span>Qty: {req.quantity.toLocaleString()}</span>
                            <span>{req.dateCreated}</span>
                          </div>
                        </button>

                        {/* Expanded requisition detail */}
                        {isExpanded && (
                          <div className="border-t border-border bg-accent/40 px-3 py-2.5">
                            <div className="flex flex-col gap-2">
                              <div className="text-[11px] text-foreground">
                                <span className="font-mono font-medium">{req.partNumber}</span>
                                {" x "}{req.quantity.toLocaleString()} units
                              </div>
                              <div className="text-[11px] text-foreground">
                                Value: <span className="font-medium">${req.value.toLocaleString()}</span>
                                {" | "}Per unit: ${(req.value / req.quantity).toFixed(2)}
                              </div>
                              {contact && (
                                <div className="flex flex-col gap-1 rounded-md border border-border bg-card p-2">
                                  <span className="text-[10px] font-medium uppercase text-muted-foreground">
                                    Contact
                                  </span>
                                  <span className="text-[11px] font-medium text-foreground">
                                    {contact.name} — {contact.title}
                                  </span>
                                  <a
                                    href={`mailto:${contact.email}`}
                                    className="flex items-center gap-1 text-[11px] text-primary hover:underline"
                                  >
                                    <Mail className="size-2.5" />
                                    {contact.email}
                                  </a>
                                  <a
                                    href={`tel:${contact.phone.replace(/[^+\d]/g, "")}`}
                                    className="flex items-center gap-1 text-[11px] text-chart-2 hover:underline"
                                  >
                                    <Phone className="size-2.5" />
                                    {contact.phone}
                                  </a>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    )
                  })}
                  {reqs.length === 0 && (
                    <p className="py-4 text-center text-xs text-muted-foreground">No requisitions</p>
                  )}
                </div>
              </ScrollArea>
            </div>
          )
        })}
      </div>
    </div>
  )
}
