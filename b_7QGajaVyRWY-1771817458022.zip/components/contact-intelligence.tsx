"use client"

import { useState, useMemo } from "react"
import { cn } from "@/lib/utils"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Input } from "@/components/ui/input"
import {
  Search,
  Building2,
  Truck,
  Clock,
  AlertCircle,
  Sparkles,
  User,
  Mail,
  Phone,
  X,
  Upload,
  Globe,
  FileInput,
} from "lucide-react"
import { getAllContacts, getRelativeTime, type Contact } from "@/lib/crm-data"

type FilterChip = "all" | "customer" | "vendor" | "recent" | "followup" | "ai"

const filterOptions: { id: FilterChip; label: string; icon: React.ElementType }[] = [
  { id: "all", label: "All", icon: User },
  { id: "customer", label: "Customer Contacts", icon: Building2 },
  { id: "vendor", label: "Vendor Contacts", icon: Truck },
  { id: "recent", label: "Recently Contacted", icon: Clock },
  { id: "followup", label: "Needs Follow-up", icon: AlertCircle },
  { id: "ai", label: "AI-Enriched", icon: Sparkles },
]

function SourceIcon({ source }: { source: Contact["source"] }) {
  const classes = "size-3 text-muted-foreground"
  switch (source) {
    case "manual":
      return <User className={classes} />
    case "email_mining":
      return <Mail className={classes} />
    case "import":
      return <FileInput className={classes} />
    case "api_enrichment":
      return <Globe className={classes} />
  }
}

function ContactDrawer({
  contact,
  onClose,
}: {
  contact: Contact
  onClose: () => void
}) {
  return (
    <div className="fixed inset-y-0 right-0 z-50 flex w-96 flex-col border-l border-border bg-card shadow-sm">
      <div className="flex items-center justify-between border-b border-border p-4">
        <h3 className="text-sm font-semibold text-foreground">{contact.name}</h3>
        <button onClick={onClose} className="rounded-md p-1 text-muted-foreground hover:bg-secondary">
          <X className="size-4" />
        </button>
      </div>
      <ScrollArea className="flex-1">
        <div className="flex flex-col gap-4 p-4">
          {/* Profile info */}
          <div className="flex items-center gap-3">
            <div className="flex size-12 items-center justify-center rounded-full bg-primary text-sm font-medium text-primary-foreground">
              {contact.name
                .split(" ")
                .map((n) => n[0])
                .join("")}
            </div>
            <div className="flex flex-col gap-0.5">
              <span className="text-sm font-medium text-foreground">{contact.name}</span>
              <span className="text-xs text-muted-foreground">{contact.title}</span>
              <div className="flex items-center gap-1.5">
                {contact.type === "customer" ? (
                  <Building2 className="size-3 text-chart-3" />
                ) : (
                  <Truck className="size-3 text-chart-2" />
                )}
                <span className="text-xs text-muted-foreground">{contact.companyName}</span>
              </div>
            </div>
          </div>

          {/* Contact details */}
          <div className="flex flex-col gap-2 rounded-md border border-border p-3">
            <div className="flex items-center gap-2 text-xs">
              <Mail className="size-3 text-muted-foreground" />
              <span className="text-foreground">{contact.email}</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <Phone className="size-3 text-muted-foreground" />
              <span className="text-foreground">{contact.phone}</span>
            </div>
          </div>

          {/* Metadata */}
          <div className="flex flex-col gap-2 rounded-md border border-border p-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Last Contacted</span>
              <span className="text-foreground">
                {getRelativeTime(contact.lastContacted + "T12:00:00Z")}
              </span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Source</span>
              <div className="flex items-center gap-1.5">
                <SourceIcon source={contact.source} />
                <span className="capitalize text-foreground">
                  {contact.source.replace("_", " ")}
                </span>
              </div>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Type</span>
              <span className="capitalize text-foreground">{contact.type}</span>
            </div>
            {contact.aiEnriched && (
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">AI Enriched</span>
                <Sparkles className="size-3 text-primary" />
              </div>
            )}
          </div>

          {/* Interaction history placeholder */}
          <div>
            <h4 className="mb-2 text-xs font-medium text-foreground">Recent Interactions</h4>
            <div className="flex flex-col gap-2">
              <div className="rounded-md bg-secondary/50 px-3 py-2 text-xs text-muted-foreground">
                Email received — 2d ago
              </div>
              <div className="rounded-md bg-secondary/50 px-3 py-2 text-xs text-muted-foreground">
                Quote sent — 5d ago
              </div>
              <div className="rounded-md bg-secondary/50 px-3 py-2 text-xs text-muted-foreground">
                Phone call — 8d ago
              </div>
            </div>
          </div>
        </div>
      </ScrollArea>
    </div>
  )
}

export function ContactIntelligence() {
  const [search, setSearch] = useState("")
  const [activeFilter, setActiveFilter] = useState<FilterChip>("all")
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null)

  const allContacts = useMemo(() => getAllContacts(), [])

  const filtered = useMemo(() => {
    let results = allContacts

    // Text search
    if (search) {
      const q = search.toLowerCase()
      results = results.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.email.toLowerCase().includes(q) ||
          c.companyName.toLowerCase().includes(q) ||
          c.title.toLowerCase().includes(q)
      )
    }

    // Filter chips
    if (activeFilter === "customer") results = results.filter((c) => c.type === "customer")
    if (activeFilter === "vendor") results = results.filter((c) => c.type === "vendor")
    if (activeFilter === "ai") results = results.filter((c) => c.aiEnriched)
    if (activeFilter === "recent") {
      results = results.filter((c) => {
        const d = new Date("2026-02-22T12:00:00Z").getTime() - new Date(c.lastContacted + "T12:00:00Z").getTime()
        return d < 7 * 86400000
      })
    }
    if (activeFilter === "followup") {
      results = results.filter((c) => {
        const d = new Date("2026-02-22T12:00:00Z").getTime() - new Date(c.lastContacted + "T12:00:00Z").getTime()
        return d > 14 * 86400000
      })
    }

    return results
  }, [allContacts, search, activeFilter])

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="flex flex-col gap-3 border-b border-border p-4">
        <div className="flex items-center justify-between">
          <h1 className="text-lg font-semibold text-foreground">Contact Intelligence</h1>
          <span className="text-xs text-muted-foreground">{filtered.length} contacts</span>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search contacts by name, email, company, or title..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-9 pl-9 text-sm"
          />
        </div>

        {/* Filter chips */}
        <div className="flex flex-wrap items-center gap-1.5">
          {filterOptions.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={cn(
                "flex items-center gap-1.5 rounded-full px-3 py-1 text-xs transition-colors",
                activeFilter === filter.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              )}
            >
              <filter.icon className="size-3" />
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Contact grid */}
      <ScrollArea className="flex-1">
        <div className="grid grid-cols-2 gap-3 p-4 xl:grid-cols-3">
          {filtered.map((contact) => (
            <button
              key={contact.id}
              onClick={() => setSelectedContact(contact)}
              className="flex items-start gap-3 rounded-md border border-border bg-card p-3 text-left transition-colors hover:bg-secondary/30"
            >
              <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-medium text-secondary-foreground">
                {contact.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </div>
              <div className="flex min-w-0 flex-1 flex-col gap-0.5">
                <div className="flex items-center gap-1.5">
                  <span className="truncate text-xs font-medium text-foreground">
                    {contact.name}
                  </span>
                  {contact.aiEnriched && <Sparkles className="size-3 shrink-0 text-primary" />}
                </div>
                <span className="truncate text-[11px] text-muted-foreground">
                  {contact.companyName}
                </span>
                <span className="truncate text-[11px] text-muted-foreground">{contact.title}</span>
                <div className="mt-1 flex items-center gap-2">
                  <span className="text-[10px] text-muted-foreground">
                    {getRelativeTime(contact.lastContacted + "T12:00:00Z")}
                  </span>
                  <SourceIcon source={contact.source} />
                </div>
              </div>
            </button>
          ))}
        </div>
      </ScrollArea>

      {/* Side drawer */}
      {selectedContact && (
        <>
          <div
            className="fixed inset-0 z-40 bg-foreground/10"
            onClick={() => setSelectedContact(null)}
          />
          <ContactDrawer
            contact={selectedContact}
            onClose={() => setSelectedContact(null)}
          />
        </>
      )}
    </div>
  )
}
