"use client"

import { useState } from "react"
import { CrmSidebar } from "@/components/crm-sidebar"
import { AccountMap } from "@/components/account-map"
import { VendorManager } from "@/components/vendor-manager"
import { CrmDashboard } from "@/components/crm-dashboard"
import { ContactIntelligence } from "@/components/contact-intelligence"
import { PipelineView } from "@/components/pipeline-view"

type View = "accounts" | "contacts" | "pipeline" | "vendors" | "dashboard"

export default function CrmApp() {
  const [activeView, setActiveView] = useState<View>("accounts")

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <CrmSidebar activeView={activeView} onViewChange={setActiveView} />
      <main className="ml-14 flex-1 overflow-hidden">
        {activeView === "accounts" && <AccountMap />}
        {activeView === "vendors" && <VendorManager />}
        {activeView === "dashboard" && <CrmDashboard />}
        {activeView === "contacts" && <ContactIntelligence />}
        {activeView === "pipeline" && <PipelineView />}
      </main>
    </div>
  )
}
