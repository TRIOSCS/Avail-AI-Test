"""Database models — Requisition-based sourcing."""
from datetime import datetime, timezone
from sqlalchemy import (
    Column, Integer, String, Float, DateTime, Text, Boolean,
    ForeignKey, JSON, Index
)
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False)
    name = Column(String(255))
    azure_id = Column(String(255), unique=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    requisitions = relationship("Requisition", back_populates="creator")
    contacts = relationship("Contact", back_populates="user")


class Requisition(Base):
    __tablename__ = "requisitions"
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    customer_name = Column(String(255))
    status = Column(String(50), default="active")
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    creator = relationship("User", back_populates="requisitions")
    requirements = relationship("Requirement", back_populates="requisition", cascade="all, delete-orphan")
    contacts = relationship("Contact", back_populates="requisition", cascade="all, delete-orphan")


class Requirement(Base):
    __tablename__ = "requirements"
    id = Column(Integer, primary_key=True)
    requisition_id = Column(Integer, ForeignKey("requisitions.id"), nullable=False)
    primary_mpn = Column(String(255))
    oem_pn = Column(String(255))
    brand = Column(String(255))
    sku = Column(String(255))
    target_qty = Column(Integer, default=1)
    substitutes = Column(JSON, default=list)
    notes = Column(Text)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    requisition = relationship("Requisition", back_populates="requirements")
    sightings = relationship("Sighting", back_populates="requirement", cascade="all, delete-orphan")

    __table_args__ = (Index("ix_req_requisition", "requisition_id"),)


class Sighting(Base):
    __tablename__ = "sightings"
    id = Column(Integer, primary_key=True)
    requirement_id = Column(Integer, ForeignKey("requirements.id"), nullable=False)
    vendor_name = Column(String(255), nullable=False)
    vendor_email = Column(String(255))
    vendor_phone = Column(String(100))
    mpn_matched = Column(String(255))
    manufacturer = Column(String(255))
    qty_available = Column(Integer)
    unit_price = Column(Float)
    currency = Column(String(10), default="USD")
    moq = Column(Integer)
    source_type = Column(String(50))
    is_authorized = Column(Boolean, default=False)
    confidence = Column(Float, default=0.0)
    score = Column(Float, default=0.0)
    raw_data = Column(JSON)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    requirement = relationship("Requirement", back_populates="sightings")

    __table_args__ = (Index("ix_sight_req", "requirement_id"),)


class Contact(Base):
    __tablename__ = "contacts"
    id = Column(Integer, primary_key=True)
    requisition_id = Column(Integer, ForeignKey("requisitions.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    contact_type = Column(String(20), nullable=False)
    vendor_name = Column(String(255), nullable=False)
    vendor_contact = Column(String(255))
    parts_included = Column(JSON, default=list)
    subject = Column(String(500))
    details = Column(Text)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    requisition = relationship("Requisition", back_populates="contacts")
    user = relationship("User", back_populates="contacts")

    __table_args__ = (Index("ix_contact_req", "requisition_id"),)


class VendorResponse(Base):
    __tablename__ = "vendor_responses"
    id = Column(Integer, primary_key=True)
    contact_id = Column(Integer, ForeignKey("contacts.id"), nullable=True)
    requisition_id = Column(Integer, ForeignKey("requisitions.id"), nullable=True)
    vendor_name = Column(String(255))
    vendor_email = Column(String(255))
    subject = Column(String(500))
    body = Column(Text)
    received_at = Column(DateTime)
    parsed_data = Column(JSON)
    confidence = Column(Float)
    status = Column(String(50), default="new")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class VendorCard(Base):
    """Vendor intelligence card — single source of truth for vendor contact info."""
    __tablename__ = "vendor_cards"
    id = Column(Integer, primary_key=True)
    normalized_name = Column(String(255), nullable=False, unique=True, index=True)
    display_name = Column(String(255), nullable=False)
    website = Column(String(500))
    emails = Column(JSON, default=list)       # Flat list, manual entries at top
    phones = Column(JSON, default=list)       # Flat list, manual entries at top
    sighting_count = Column(Integer, default=0)
    is_blacklisted = Column(Boolean, default=False)
    source = Column(String(50))               # "ai_lookup", "brokerbin", "manual"
    raw_response = Column(Text)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    reviews = relationship("VendorReview", back_populates="vendor_card", cascade="all, delete-orphan")


class VendorReview(Base):
    """Individual vendor rating + comment from a team member."""
    __tablename__ = "vendor_reviews"
    id = Column(Integer, primary_key=True)
    vendor_card_id = Column(Integer, ForeignKey("vendor_cards.id"), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    rating = Column(Integer, nullable=False)  # 1-5 stars
    comment = Column(String(500))
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    vendor_card = relationship("VendorCard", back_populates="reviews")
    user = relationship("User")

    __table_args__ = (Index("ix_review_vendor", "vendor_card_id"),)


class MaterialCard(Base):
    """Material intelligence card — everything we know about a part number."""
    __tablename__ = "material_cards"
    id = Column(Integer, primary_key=True)
    normalized_mpn = Column(String(255), nullable=False, unique=True, index=True)
    display_mpn = Column(String(255), nullable=False)
    manufacturer = Column(String(255))
    description = Column(String(1000))
    search_count = Column(Integer, default=0)
    last_searched_at = Column(DateTime)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    vendor_history = relationship("MaterialVendorHistory", back_populates="material_card", cascade="all, delete-orphan")


class MaterialVendorHistory(Base):
    """One record per vendor × MPN — tracks every vendor who has ever listed the part."""
    __tablename__ = "material_vendor_history"
    id = Column(Integer, primary_key=True)
    material_card_id = Column(Integer, ForeignKey("material_cards.id"), nullable=False)
    vendor_name = Column(String(255), nullable=False)
    source_type = Column(String(50))          # "octopart", "brokerbin", etc.
    is_authorized = Column(Boolean, default=False)
    first_seen = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_seen = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    times_seen = Column(Integer, default=1)
    last_qty = Column(Integer)
    last_price = Column(Float)
    last_currency = Column(String(10), default="USD")
    last_manufacturer = Column(String(255))
    vendor_sku = Column(String(255))
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    material_card = relationship("MaterialCard", back_populates="vendor_history")

    __table_args__ = (
        Index("ix_mvh_card_vendor", "material_card_id", "vendor_name", unique=True),
        Index("ix_mvh_vendor", "vendor_name"),
    )
