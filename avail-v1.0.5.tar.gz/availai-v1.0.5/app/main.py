"""FastAPI application — all routes."""
import io, csv, json, re, logging
from datetime import datetime, timezone
from fastapi import FastAPI, Request, UploadFile, File, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session
from sqlalchemy import func as sqlfunc
from starlette.middleware.sessions import SessionMiddleware
import httpx

from .config import settings
from .database import engine, get_db
from .models import Base, User, Requisition, Requirement, Sighting, Contact, VendorResponse, VendorCard, VendorReview, MaterialCard, MaterialVendorHistory
from .search_service import search_requirement, sighting_to_dict, normalize_mpn
from .email_service import send_batch_rfq, log_phone_contact, poll_inbox
from .vendor_utils import normalize_vendor_name

log = logging.getLogger(__name__)

Base.metadata.create_all(bind=engine)

app = FastAPI(title="AVAIL — Opportunity Management")
app.add_middleware(SessionMiddleware, secret_key=settings.secret_key)
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

# ── Helpers ──────────────────────────────────────────────────────────────
AZURE_AUTH = f"https://login.microsoftonline.com/{settings.azure_tenant_id}/oauth2/v2.0"
SCOPES = "openid profile email Mail.Send Mail.Read"


def get_user(request: Request, db: Session) -> User | None:
    uid = request.session.get("user_id")
    if not uid:
        return None
    try:
        return db.query(User).get(uid)
    except Exception:
        request.session.clear()
        return None


def require_user(request: Request, db: Session = Depends(get_db)) -> User:
    user = get_user(request, db)
    if not user:
        raise HTTPException(401, "Not authenticated")
    return user


def require_token(request: Request) -> str:
    token = request.session.get("access_token")
    if not token:
        raise HTTPException(401, "No access token")
    return token


# ── Pages ────────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse)
async def index(request: Request, db: Session = Depends(get_db)):
    user = get_user(request, db)
    return templates.TemplateResponse("index.html", {
        "request": request,
        "logged_in": user is not None,
        "user_name": user.name if user else "",
    })


# ── Auth ─────────────────────────────────────────────────────────────────
@app.get("/auth/login")
async def login():
    return RedirectResponse(
        f"{AZURE_AUTH}/authorize?client_id={settings.azure_client_id}"
        f"&response_type=code&redirect_uri={settings.app_url}/auth/callback"
        f"&scope={SCOPES}&response_mode=query"
    )


@app.get("/auth/callback")
async def callback(request: Request, code: str = "", db: Session = Depends(get_db)):
    if not code:
        return RedirectResponse("/")
    async with httpx.AsyncClient() as client:
        resp = await client.post(f"{AZURE_AUTH}/token", data={
            "client_id": settings.azure_client_id,
            "client_secret": settings.azure_client_secret,
            "code": code,
            "grant_type": "authorization_code",
            "redirect_uri": f"{settings.app_url}/auth/callback",
            "scope": SCOPES,
        })
    if resp.status_code != 200:
        return RedirectResponse("/")
    tokens = resp.json()
    request.session["access_token"] = tokens["access_token"]

    async with httpx.AsyncClient() as client:
        me = await client.get("https://graph.microsoft.com/v1.0/me",
            headers={"Authorization": f"Bearer {tokens['access_token']}"})
    profile = me.json()
    email = profile.get("mail") or profile.get("userPrincipalName", "")
    user = db.query(User).filter_by(email=email).first()
    if not user:
        user = User(email=email, name=profile.get("displayName", email),
                     azure_id=profile.get("id"))
        db.add(user)
        db.commit()
    request.session["user_id"] = user.id
    return RedirectResponse("/")


@app.post("/auth/logout")
async def logout(request: Request):
    request.session.clear()
    return JSONResponse({"ok": True})


# ── Requisitions ─────────────────────────────────────────────────────────
@app.get("/api/requisitions")
async def list_requisitions(user: User = Depends(require_user), db: Session = Depends(get_db)):
    reqs = db.query(Requisition).filter_by(created_by=user.id).order_by(Requisition.created_at.desc()).all()
    return [{
        "id": r.id,
        "name": r.name,
        "status": r.status,
        "requirement_count": len(r.requirements),
        "contact_count": len(r.contacts),
        "created_at": r.created_at.isoformat() if r.created_at else None,
    } for r in reqs]


@app.post("/api/requisitions")
async def create_requisition(request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    data = await request.json()
    req = Requisition(name=data.get("name", "Untitled"), created_by=user.id)
    db.add(req)
    db.commit()
    return {"id": req.id, "name": req.name}


@app.delete("/api/requisitions/{req_id}")
async def delete_requisition(req_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    req = db.query(Requisition).filter_by(id=req_id, created_by=user.id).first()
    if not req:
        raise HTTPException(404)
    db.delete(req)
    db.commit()
    return {"ok": True}


# ── Requirements ─────────────────────────────────────────────────────────
@app.get("/api/requisitions/{req_id}/requirements")
async def list_requirements(req_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    req = db.query(Requisition).filter_by(id=req_id, created_by=user.id).first()
    if not req:
        raise HTTPException(404)
    return [{
        "id": r.id,
        "primary_mpn": r.primary_mpn,
        "target_qty": r.target_qty,
        "substitutes": r.substitutes or [],
        "sighting_count": len(r.sightings),
    } for r in req.requirements]


@app.post("/api/requisitions/{req_id}/requirements")
async def add_requirements(req_id: int, request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    req = db.query(Requisition).filter_by(id=req_id, created_by=user.id).first()
    if not req:
        raise HTTPException(404)
    data = await request.json()
    items = data if isinstance(data, list) else [data]
    created = []
    for item in items:
        mpn = (item.get("primary_mpn") or "").strip()
        if not mpn:
            continue
        subs = item.get("substitutes", [])
        if isinstance(subs, str):
            subs = [s.strip() for s in subs.replace("\n", ",").split(",") if s.strip()]
        r = Requirement(requisition_id=req_id, primary_mpn=mpn,
                        target_qty=int(item.get("target_qty", 1) or 1), substitutes=subs[:20])
        db.add(r)
        created.append(r)
    db.commit()
    return [{"id": r.id, "primary_mpn": r.primary_mpn} for r in created]


@app.post("/api/requisitions/{req_id}/upload")
async def upload_requirements(req_id: int, file: UploadFile = File(...),
                               user: User = Depends(require_user), db: Session = Depends(get_db)):
    req = db.query(Requisition).filter_by(id=req_id, created_by=user.id).first()
    if not req:
        raise HTTPException(404)
    content = await file.read()
    fname = (file.filename or "").lower()
    rows = []
    if fname.endswith((".xlsx", ".xls")):
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(content), read_only=True)
        ws = wb.active
        headers = [str(c.value or "").strip().lower() for c in next(ws.iter_rows(max_row=1))]
        for row in ws.iter_rows(min_row=2, values_only=True):
            rows.append(dict(zip(headers, [str(v or "").strip() for v in row])))
    else:
        text = content.decode("utf-8-sig", errors="replace")
        delimiter = "\t" if fname.endswith(".tsv") else ","
        reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
        for row in reader:
            rows.append({k.strip().lower(): v.strip() for k, v in row.items() if k})

    created = 0
    for row in rows:
        mpn = (row.get("primary_mpn") or row.get("mpn") or row.get("part_number")
               or row.get("part") or row.get("pn") or row.get("oem_pn")
               or row.get("oem") or row.get("sku") or "")
        if not mpn:
            continue
        qty = row.get("target_qty") or row.get("qty") or row.get("quantity") or "1"
        subs = []
        sub_str = row.get("substitutes") or row.get("subs") or ""
        if sub_str:
            subs = [s.strip() for s in sub_str.replace("\n", ",").split(",") if s.strip()]
        for i in range(1, 21):
            s = row.get(f"sub_{i}") or row.get(f"sub{i}") or ""
            if s:
                subs.append(s)
        r = Requirement(requisition_id=req_id, primary_mpn=mpn,
                        target_qty=int(qty) if qty.isdigit() else 1, substitutes=subs[:20])
        db.add(r)
        created += 1
    db.commit()
    return {"created": created, "total_rows": len(rows)}


@app.delete("/api/requirements/{item_id}")
async def delete_requirement(item_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    r = db.query(Requirement).get(item_id)
    if not r:
        raise HTTPException(404)
    req = db.query(Requisition).filter_by(id=r.requisition_id, created_by=user.id).first()
    if not req:
        raise HTTPException(403)
    db.delete(r)
    db.commit()
    return {"ok": True}


# ── Search ───────────────────────────────────────────────────────────────
@app.post("/api/requisitions/{req_id}/search")
async def search_all(req_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    req = db.query(Requisition).filter_by(id=req_id, created_by=user.id).first()
    if not req:
        raise HTTPException(404)
    results = {}
    for r in req.requirements:
        sightings = await search_requirement(r, db)
        label = r.primary_mpn or f"Req #{r.id}"
        results[str(r.id)] = {"label": label, "sightings": sightings}

    # Enrich with vendor card ratings (no contact lookup — that happens at RFQ time)
    _enrich_with_vendor_cards(results, db)
    return results


@app.post("/api/requirements/{item_id}/search")
async def search_one(item_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    r = db.query(Requirement).get(item_id)
    if not r:
        raise HTTPException(404)
    sightings = await search_requirement(r, db)
    # Wrap in same structure as search_all so enrichment works
    results = {str(r.id): {"label": r.primary_mpn or f"Req #{r.id}", "sightings": sightings}}
    _enrich_with_vendor_cards(results, db)
    return {"sightings": results[str(r.id)]["sightings"]}


# ── Contacts ─────────────────────────────────────────────────────────────
@app.post("/api/contacts/phone")
async def log_call(request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    data = await request.json()
    return log_phone_contact(db=db, user_id=user.id, requisition_id=data["requisition_id"],
                             vendor_name=data["vendor_name"], vendor_phone=data["vendor_phone"],
                             parts=data.get("parts", []))


@app.get("/api/requisitions/{req_id}/contacts")
async def list_contacts(req_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    contacts = db.query(Contact).filter_by(requisition_id=req_id).order_by(Contact.created_at.desc()).all()
    return [{
        "id": c.id, "contact_type": c.contact_type, "vendor_name": c.vendor_name,
        "vendor_contact": c.vendor_contact, "parts_included": c.parts_included,
        "subject": c.subject,
        "created_at": c.created_at.isoformat() if c.created_at else None,
        "user_name": c.user.name if c.user else "",
    } for c in contacts]


# ── Batch RFQ ────────────────────────────────────────────────────────────
@app.post("/api/requisitions/{req_id}/rfq")
async def send_rfq(req_id: int, request: Request,
                    user: User = Depends(require_user), db: Session = Depends(get_db)):
    token = require_token(request)
    data = await request.json()
    results = await send_batch_rfq(token=token, db=db, user_id=user.id,
                                   requisition_id=req_id, vendor_groups=data.get("groups", []))
    return {"results": results}


# ── Inbox Polling ────────────────────────────────────────────────────────
@app.post("/api/requisitions/{req_id}/poll")
async def poll(req_id: int, request: Request,
               user: User = Depends(require_user), db: Session = Depends(get_db)):
    token = require_token(request)
    results = await poll_inbox(token, db, requisition_id=req_id)
    return {"responses": results}


@app.get("/api/requisitions/{req_id}/responses")
async def list_responses(req_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    resps = db.query(VendorResponse).filter_by(requisition_id=req_id).order_by(VendorResponse.created_at.desc()).all()
    return [{
        "id": r.id, "vendor_name": r.vendor_name, "vendor_email": r.vendor_email,
        "subject": r.subject, "status": r.status, "parsed_data": r.parsed_data,
        "confidence": r.confidence,
        "received_at": r.received_at.isoformat() if isinstance(r.received_at, datetime) else r.received_at,
    } for r in resps]


# ══════════════════════════════════════════════════════════════════════════
# VENDOR CARD SYSTEM
# ══════════════════════════════════════════════════════════════════════════

def _get_or_create_card(vendor_name: str, db: Session) -> VendorCard:
    norm = normalize_vendor_name(vendor_name)
    card = db.query(VendorCard).filter_by(normalized_name=norm).first()
    if not card:
        card = VendorCard(normalized_name=norm, display_name=vendor_name, emails=[], phones=[])
        db.add(card)
        db.commit()
    return card


def _card_to_dict(card: VendorCard, db: Session) -> dict:
    reviews = db.query(VendorReview).filter_by(vendor_card_id=card.id).all()
    avg = round(sum(r.rating for r in reviews) / len(reviews), 1) if reviews else None
    return {
        "id": card.id,
        "normalized_name": card.normalized_name,
        "display_name": card.display_name,
        "website": card.website,
        "emails": card.emails or [],
        "phones": card.phones or [],
        "sighting_count": card.sighting_count or 0,
        "is_blacklisted": card.is_blacklisted or False,
        "avg_rating": avg,
        "review_count": len(reviews),
        "reviews": [{
            "id": r.id, "user_id": r.user_id,
            "user_name": r.user.name if r.user else "",
            "rating": r.rating, "comment": r.comment,
            "created_at": r.created_at.isoformat() if r.created_at else None,
        } for r in reviews],
        "created_at": card.created_at.isoformat() if card.created_at else None,
        "updated_at": card.updated_at.isoformat() if card.updated_at else None,
    }


# ── Vendor Cards CRUD ───────────────────────────────────────────────────
@app.get("/api/vendors")
async def list_vendors(request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    q = request.query_params.get("q", "").strip().lower()
    query = db.query(VendorCard).order_by(VendorCard.display_name)
    if q:
        query = query.filter(VendorCard.normalized_name.ilike(f"%{q}%"))
    cards = query.all()
    if not cards:
        return []
    # Batch fetch review stats — single query instead of N+1
    card_ids = [c.id for c in cards]
    review_stats = {}
    if card_ids:
        for cid, avg, cnt in db.query(
            VendorReview.vendor_card_id,
            sqlfunc.avg(VendorReview.rating),
            sqlfunc.count(VendorReview.id),
        ).filter(VendorReview.vendor_card_id.in_(card_ids)).group_by(VendorReview.vendor_card_id).all():
            review_stats[cid] = (avg, cnt)
    results = []
    for c in cards:
        stat = review_stats.get(c.id)
        avg_rating = round(float(stat[0]), 1) if stat else None
        review_count = int(stat[1]) if stat else 0
        results.append({
            "id": c.id, "display_name": c.display_name,
            "emails": c.emails or [], "phones": c.phones or [],
            "sighting_count": c.sighting_count or 0,
            "is_blacklisted": c.is_blacklisted or False,
            "avg_rating": avg_rating, "review_count": review_count,
        })
    return results


@app.get("/api/vendors/{card_id}")
async def get_vendor(card_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    card = db.query(VendorCard).get(card_id)
    if not card:
        raise HTTPException(404)
    return _card_to_dict(card, db)


@app.put("/api/vendors/{card_id}")
async def update_vendor(card_id: int, request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    card = db.query(VendorCard).get(card_id)
    if not card:
        raise HTTPException(404)
    data = await request.json()
    if "emails" in data:
        card.emails = list(dict.fromkeys([e.strip().lower() for e in data["emails"] if e and "@" in str(e)]))
    if "phones" in data:
        card.phones = list(dict.fromkeys([p.strip() for p in data["phones"] if p and p.strip()]))
    if "website" in data:
        card.website = data["website"]
    if "display_name" in data and data["display_name"].strip():
        card.display_name = data["display_name"].strip()
    if "is_blacklisted" in data:
        card.is_blacklisted = bool(data["is_blacklisted"])
    db.commit()
    return _card_to_dict(card, db)


@app.post("/api/vendors/{card_id}/blacklist")
async def toggle_blacklist(card_id: int, request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    """Toggle vendor blacklist status."""
    card = db.query(VendorCard).get(card_id)
    if not card:
        raise HTTPException(404)
    data = await request.json()
    card.is_blacklisted = bool(data.get("blacklisted", not card.is_blacklisted))
    db.commit()
    return _card_to_dict(card, db)


@app.delete("/api/vendors/{card_id}")
async def delete_vendor(card_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    card = db.query(VendorCard).get(card_id)
    if not card:
        raise HTTPException(404)
    db.delete(card)
    db.commit()
    return {"ok": True}


# ── Vendor Reviews ──────────────────────────────────────────────────────
@app.post("/api/vendors/{card_id}/reviews")
async def add_review(card_id: int, request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    card = db.query(VendorCard).get(card_id)
    if not card:
        raise HTTPException(404)
    data = await request.json()
    rating = max(1, min(5, int(data.get("rating", 3))))
    review = VendorReview(vendor_card_id=card.id, user_id=user.id,
                          rating=rating, comment=(data.get("comment") or "")[:500])
    db.add(review)
    db.commit()
    return _card_to_dict(card, db)


@app.delete("/api/vendors/{card_id}/reviews/{review_id}")
async def delete_review(card_id: int, review_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    review = db.query(VendorReview).filter_by(id=review_id, vendor_card_id=card_id, user_id=user.id).first()
    if not review:
        raise HTTPException(404, "Review not found or not yours")
    db.delete(review)
    db.commit()
    return _card_to_dict(db.query(VendorCard).get(card_id), db)


# ── Vendor Contact Lookup (AI) — creates/updates vendor card ───────────
@app.post("/api/vendor-contact")
async def lookup_vendor_contact(request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    data = await request.json()
    vendor_name = (data.get("vendor_name") or "").strip()
    if not vendor_name:
        raise HTTPException(400, "vendor_name required")

    norm = normalize_vendor_name(vendor_name)
    card = db.query(VendorCard).filter_by(normalized_name=norm).first()

    if card and card.emails:
        return {"vendor_name": card.display_name, "emails": card.emails or [],
                "phones": card.phones or [], "website": card.website,
                "card_id": card.id, "source": "cached", "cached": True}

    if not settings.anthropic_api_key:
        return {"vendor_name": vendor_name, "emails": [], "phones": [], "website": None,
                "card_id": card.id if card else None, "source": None, "cached": False,
                "error": "No API key configured"}

    try:
        async with httpx.AsyncClient(timeout=45) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": settings.anthropic_api_key,
                    "anthropic-version": "2023-06-01",
                    "Content-Type": "application/json",
                },
                json={
                    "model": "claude-sonnet-4-20250514",
                    "max_tokens": 1024,
                    "tools": [{"type": "web_search_20250305", "name": "web_search"}],
                    "messages": [{
                        "role": "user",
                        "content": (
                            f"Find ALL contact email addresses and phone numbers for the "
                            f"electronic component distributor '{vendor_name}'. "
                            f"I need every email you can find — sales, RFQ, quotes, general inquiry, "
                            f"info@, support, specific salespeople. "
                            f"Return ONLY a JSON object: "
                            f'{{"emails": [...], "phones": [...], "website": "..."}}. '
                            f"If you cannot find a field, set it to null or empty array. No explanation."
                        )
                    }],
                },
            )
            resp.raise_for_status()
            result = resp.json()

            text = ""
            for block in result.get("content", []):
                if block.get("type") == "text":
                    text += block.get("text", "")

            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            info = json.loads(json_match.group()) if json_match else {}

            all_emails = info.get("emails") or []
            if isinstance(all_emails, str): all_emails = [all_emails]
            single_email = info.get("email")
            if single_email and single_email not in all_emails:
                all_emails.insert(0, single_email)
            all_emails = list(dict.fromkeys([e.strip().lower() for e in all_emails if e and "@" in str(e)]))

            all_phones = info.get("phones") or []
            if isinstance(all_phones, str): all_phones = [all_phones]
            single_phone = info.get("phone")
            if single_phone and single_phone not in all_phones:
                all_phones.insert(0, single_phone)
            all_phones = list(dict.fromkeys([p.strip() for p in all_phones if p and p.strip()]))

            website = info.get("website")

            if not card:
                card = VendorCard(normalized_name=norm, display_name=vendor_name)
                db.add(card)
            card.emails = all_emails
            card.phones = all_phones
            if website: card.website = website
            card.source = "ai_lookup"
            card.raw_response = text[:1000]
            db.commit()

            return {"vendor_name": card.display_name, "emails": all_emails,
                    "phones": all_phones, "website": website,
                    "card_id": card.id, "source": "ai_lookup", "cached": False}

    except Exception as e:
        log.warning(f"Vendor contact lookup failed for {vendor_name}: {e}")
        return {"vendor_name": vendor_name, "emails": [], "phones": [], "website": None,
                "card_id": card.id if card else None, "source": None, "cached": False,
                "error": str(e)[:200]}


# ── RFQ Prepare ─────────────────────────────────────────────────────────
@app.post("/api/requisitions/{req_id}/rfq-prepare")
async def rfq_prepare(req_id: int, request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    """Return vendor card data for selected vendors before RFQ send."""
    data = await request.json()
    vendors = data.get("vendors", [])
    results = []
    for v in vendors[:50]:
        vendor_name = v.get("vendor_name", "") if isinstance(v, dict) else str(v)
        norm = normalize_vendor_name(vendor_name)
        card = db.query(VendorCard).filter_by(normalized_name=norm).first()
        if card and card.emails:
            results.append({"vendor_name": vendor_name, "display_name": card.display_name,
                            "emails": card.emails or [], "phones": card.phones or [],
                            "card_id": card.id, "needs_lookup": False})
        else:
            results.append({"vendor_name": vendor_name,
                            "display_name": card.display_name if card else vendor_name,
                            "emails": [], "phones": [],
                            "card_id": card.id if card else None, "needs_lookup": True})
    return {"vendors": results}


# ── Add Email to Vendor Card ───────────────────────────────────────────
@app.post("/api/vendor-card/add-email")
async def add_email_to_card(request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    data = await request.json()
    vendor_name = (data.get("vendor_name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    if not vendor_name or not email or "@" not in email:
        raise HTTPException(400, "vendor_name and valid email required")
    card = _get_or_create_card(vendor_name, db)
    emails = [e for e in (card.emails or []) if e.lower() != email]
    emails.insert(0, email)  # Manual entries go to the top
    card.emails = emails
    db.commit()
    return {"ok": True, "card_id": card.id, "emails": card.emails}


# ══════════════════════════════════════════════════════════════════════════
# MATERIAL CARD SYSTEM
# ══════════════════════════════════════════════════════════════════════════

def _material_card_to_dict(card: MaterialCard, db: Session) -> dict:
    """Serialize a material card with vendor history."""
    history = (
        db.query(MaterialVendorHistory)
        .filter_by(material_card_id=card.id)
        .order_by(MaterialVendorHistory.last_seen.desc())
        .all()
    )
    return {
        "id": card.id,
        "normalized_mpn": card.normalized_mpn,
        "display_mpn": card.display_mpn,
        "manufacturer": card.manufacturer,
        "description": card.description,
        "search_count": card.search_count or 0,
        "last_searched_at": card.last_searched_at.isoformat() if card.last_searched_at else None,
        "vendor_count": len(history),
        "vendor_history": [{
            "id": vh.id,
            "vendor_name": vh.vendor_name,
            "source_type": vh.source_type,
            "is_authorized": vh.is_authorized,
            "first_seen": vh.first_seen.isoformat() if vh.first_seen else None,
            "last_seen": vh.last_seen.isoformat() if vh.last_seen else None,
            "times_seen": vh.times_seen or 1,
            "last_qty": vh.last_qty,
            "last_price": vh.last_price,
            "last_currency": vh.last_currency,
            "last_manufacturer": vh.last_manufacturer,
            "vendor_sku": vh.vendor_sku,
        } for vh in history],
        "created_at": card.created_at.isoformat() if card.created_at else None,
        "updated_at": card.updated_at.isoformat() if card.updated_at else None,
    }


@app.get("/api/materials")
async def list_materials(request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    q = request.query_params.get("q", "").strip().lower()
    query = db.query(MaterialCard).order_by(MaterialCard.last_searched_at.desc())
    if q:
        query = query.filter(MaterialCard.normalized_mpn.ilike(f"{q}%"))
    cards = query.all()
    if not cards:
        return []
    # Batch fetch vendor counts — single query
    card_ids = [c.id for c in cards]
    counts = dict(
        db.query(MaterialVendorHistory.material_card_id, sqlfunc.count(MaterialVendorHistory.id))
        .filter(MaterialVendorHistory.material_card_id.in_(card_ids))
        .group_by(MaterialVendorHistory.material_card_id)
        .all()
    ) if card_ids else {}
    return [{
        "id": c.id, "display_mpn": c.display_mpn, "manufacturer": c.manufacturer,
        "search_count": c.search_count or 0,
        "vendor_count": counts.get(c.id, 0),
        "last_searched_at": c.last_searched_at.isoformat() if c.last_searched_at else None,
    } for c in cards]


@app.get("/api/materials/{card_id}")
async def get_material(card_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    card = db.query(MaterialCard).get(card_id)
    if not card:
        raise HTTPException(404)
    return _material_card_to_dict(card, db)


@app.get("/api/materials/by-mpn/{mpn}")
async def get_material_by_mpn(mpn: str, user: User = Depends(require_user), db: Session = Depends(get_db)):
    """Look up a material card by MPN."""
    norm = normalize_mpn(mpn)
    card = db.query(MaterialCard).filter_by(normalized_mpn=norm).first()
    if not card:
        raise HTTPException(404, "No material card found for this MPN")
    return _material_card_to_dict(card, db)


@app.put("/api/materials/{card_id}")
async def update_material(card_id: int, request: Request, user: User = Depends(require_user), db: Session = Depends(get_db)):
    card = db.query(MaterialCard).get(card_id)
    if not card:
        raise HTTPException(404)
    data = await request.json()
    if "manufacturer" in data:
        card.manufacturer = data["manufacturer"]
    if "description" in data:
        card.description = data["description"]
    if "display_mpn" in data and data["display_mpn"].strip():
        card.display_mpn = data["display_mpn"].strip()
    db.commit()
    return _material_card_to_dict(card, db)


@app.delete("/api/materials/{card_id}")
async def delete_material(card_id: int, user: User = Depends(require_user), db: Session = Depends(get_db)):
    card = db.query(MaterialCard).get(card_id)
    if not card:
        raise HTTPException(404)
    db.delete(card)
    db.commit()
    return {"ok": True}


# ── Search enrichment with vendor cards ────────────────────────────────
def _enrich_with_vendor_cards(results: dict, db: Session):
    """Add vendor card rating info to search results. No contact lookup."""
    all_vendor_names = set()
    for group in results.values():
        for s in group.get("sightings", []):
            if s.get("vendor_name"):
                all_vendor_names.add(s["vendor_name"])
    if not all_vendor_names:
        return

    # Build normalized name map
    norm_map = {}
    for name in all_vendor_names:
        norm = normalize_vendor_name(name)
        norm_map.setdefault(norm, []).append(name)

    cards = db.query(VendorCard).filter(VendorCard.normalized_name.in_(norm_map.keys())).all()
    card_by_norm = {c.normalized_name: c for c in cards}

    # Batch fetch reviews
    card_ids = [c.id for c in cards]
    all_reviews = db.query(VendorReview).filter(VendorReview.vendor_card_id.in_(card_ids)).all() if card_ids else []
    reviews_by_card = {}
    for r in all_reviews:
        reviews_by_card.setdefault(r.vendor_card_id, []).append(r)

    # Build summary cache
    summary_cache = {}
    for norm, card in card_by_norm.items():
        revs = reviews_by_card.get(card.id, [])
        avg = round(sum(r.rating for r in revs) / len(revs), 1) if revs else None
        summary_cache[norm] = {
            "card_id": card.id, "avg_rating": avg,
            "review_count": len(revs),
            "has_emails": bool(card.emails),
            "email_count": len(card.emails or []),
            "is_blacklisted": card.is_blacklisted or False,
        }

    # Increment sighting counts — pre-count per normalized name
    count_by_norm = {}
    for group in results.values():
        for s in group.get("sightings", []):
            if not s.get("is_historical") and s.get("vendor_name"):
                n = normalize_vendor_name(s["vendor_name"])
                count_by_norm[n] = count_by_norm.get(n, 0) + 1
    for card in cards:
        count = count_by_norm.get(card.normalized_name, 0)
        if count > 0:
            card.sighting_count = (card.sighting_count or 0) + count
    if cards:
        db.commit()

    # Enrich each sighting + filter blacklisted
    empty_summary = {"card_id": None, "avg_rating": None, "review_count": 0, "has_emails": False, "email_count": 0, "is_blacklisted": False}
    for group in results.values():
        enriched = []
        for s in group.get("sightings", []):
            norm = normalize_vendor_name(s.get("vendor_name", ""))
            summary = summary_cache.get(norm, empty_summary)
            if summary.get("is_blacklisted"):
                continue  # Skip blacklisted vendors
            s["vendor_card"] = summary
            enriched.append(s)
        group["sightings"] = enriched
