/* AVAIL v1.0.5 — Vendor Cards + Material Intelligence */

let currentReqId = null;
let currentReqName = '';
let searchResults = {};
let selectedSightings = new Set();
let rfqVendorData = [];

// ── Utilities ───────────────────────────────────────────────────────────
function esc(s) {
    if (!s) return '';
    const d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
}
function escAttr(s) {
    if (!s) return '';
    return s.replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function fmtDate(iso) {
    if (!iso) return '';
    return new Date(iso).toLocaleDateString();
}
function fmtDateTime(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
}
function stars(avg, count) {
    if (avg === null || avg === undefined) return '<span class="stars-none">☆</span>';
    const full = Math.floor(avg);
    const half = avg - full >= 0.5 ? 1 : 0;
    let s = '<span class="stars">';
    for (let i = 0; i < full; i++) s += '★';
    if (half) s += '½';
    s += `</span><span class="stars-num">${avg}</span>`;
    if (count > 0) s += `<span class="stars-count">(${count})</span>`;
    return s;
}

// ── Init ────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    loadRequisitions();
    const dz = document.getElementById('dropZone');
    if (dz) {
        dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('drag'); });
        dz.addEventListener('dragleave', () => dz.classList.remove('drag'));
        dz.addEventListener('drop', e => {
            e.preventDefault(); dz.classList.remove('drag');
            if (e.dataTransfer.files.length) {
                document.getElementById('fileInput').files = e.dataTransfer.files;
                doUpload();
            }
        });
    }
});

// ── Navigation ──────────────────────────────────────────────────────────
const ALL_VIEWS = ['view-list', 'view-detail', 'view-vendors', 'view-materials'];

function showView(viewId) {
    for (const id of ALL_VIEWS) {
        document.getElementById(id).style.display = id === viewId ? '' : 'none';
    }
}

function showList() {
    showView('view-list');
    currentReqId = null;
    loadRequisitions();
}

function showDetail(id, name) {
    currentReqId = id;
    currentReqName = name;
    showView('view-detail');
    document.getElementById('detailTitle').textContent = name;
    searchResults = {};
    selectedSightings.clear();
    loadRequirements();
    loadActivity();
    switchTab('requirements', document.querySelector('.tab'));
}

function showVendors() {
    showView('view-vendors');
    currentReqId = null;
    loadVendorList();
}

function showMaterials() {
    showView('view-materials');
    currentReqId = null;
    loadMaterialList();
}

function switchTab(name, btn) {
    document.querySelectorAll('.tc').forEach(t => t.classList.remove('on'));
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('on'));
    document.getElementById('tab-' + name).classList.add('on');
    btn.classList.add('on');
}

// ── Modals ──────────────────────────────────────────────────────────────
function openNewReqModal() {
    document.getElementById('newReqModal').classList.add('open');
    setTimeout(() => document.getElementById('nrName').focus(), 100);
}
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

// ── Requisitions ────────────────────────────────────────────────────────
async function loadRequisitions() {
    const res = await fetch('/api/requisitions');
    if (!res.ok) return;
    const data = await res.json();
    const el = document.getElementById('reqList');
    if (!data.length) {
        el.innerHTML = '<p class="empty">No requisitions yet — create one to get started</p>';
        return;
    }
    el.innerHTML = data.map(r => `
        <div class="card card-clickable" onclick="showDetail(${r.id}, '${escAttr(r.name)}')">
            <div class="req-card">
                <div class="req-name">${esc(r.name)}</div>
                <div class="req-meta">
                    <span>${r.requirement_count} parts</span>
                    <span>${r.contact_count} contacts</span>
                    <span>${fmtDate(r.created_at)}</span>
                    <button class="btn btn-danger btn-sm" onclick="event.stopPropagation();deleteRequisition(${r.id},'${escAttr(r.name)}')" title="Delete">✕</button>
                </div>
            </div>
        </div>
    `).join('');
}

async function createRequisition() {
    const name = document.getElementById('nrName').value.trim();
    if (!name) return;
    const res = await fetch('/api/requisitions', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ name })
    });
    if (res.ok) {
        const data = await res.json();
        closeModal('newReqModal');
        document.getElementById('nrName').value = '';
        showDetail(data.id, data.name);
    }
}

async function deleteRequisition(id, name) {
    if (!confirm(`Delete "${name}" and all its requirements?`)) return;
    const res = await fetch(`/api/requisitions/${id}`, { method: 'DELETE' });
    if (res.ok) loadRequisitions();
}

// ── Requirements ────────────────────────────────────────────────────────
async function loadRequirements() {
    if (!currentReqId) return;
    const res = await fetch(`/api/requisitions/${currentReqId}/requirements`);
    if (!res.ok) return;
    const data = await res.json();
    const el = document.getElementById('reqTable');
    if (!data.length) {
        el.innerHTML = '<tr><td colspan="5" class="empty">No parts yet — add one below</td></tr>';
        return;
    }
    el.innerHTML = data.map(r => {
        const subsText = (r.substitutes || []).length ? r.substitutes.join(', ') : '—';
        return `<tr>
            <td class="mono">${esc(r.primary_mpn || '—')}</td>
            <td class="mono">${r.target_qty}</td>
            <td style="font-size:11px;color:var(--text2)">${esc(subsText)}</td>
            <td class="mono">${r.sighting_count}</td>
            <td><button class="btn btn-danger btn-sm" onclick="deleteReq(${r.id})" title="Remove">✕</button></td>
        </tr>`;
    }).join('');
}

async function addReq() {
    if (!currentReqId) return;
    const mpnEl = document.getElementById('fMpn');
    const qtyEl = document.getElementById('fQty');
    const subsEl = document.getElementById('fSubs');
    const mpn = mpnEl.value.trim();
    if (!mpn) { mpnEl.focus(); return; }
    const res = await fetch(`/api/requisitions/${currentReqId}/requirements`, {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ primary_mpn: mpn, target_qty: qtyEl.value || '1', substitutes: subsEl.value.trim() })
    });
    if (res.ok) {
        mpnEl.value = ''; subsEl.value = ''; qtyEl.value = '1';
        mpnEl.focus();
        loadRequirements();
    }
}

async function deleteReq(id) {
    if (!confirm('Remove this requirement?')) return;
    await fetch(`/api/requirements/${id}`, { method: 'DELETE' });
    loadRequirements();
}

function toggleUpload() {
    const el = document.getElementById('uploadArea');
    el.style.display = el.style.display === 'none' ? '' : 'none';
}

async function doUpload() {
    const file = document.getElementById('fileInput').files[0];
    if (!file || !currentReqId) return;
    const st = document.getElementById('uploadStatus');
    st.className = 'ustatus load'; st.textContent = 'Uploading…'; st.style.display = 'block';
    const fd = new FormData(); fd.append('file', file);
    try {
        const res = await fetch(`/api/requisitions/${currentReqId}/upload`, { method: 'POST', body: fd });
        const data = await res.json();
        if (res.ok) {
            st.className = 'ustatus ok';
            st.textContent = `Added ${data.created} parts from ${data.total_rows} rows`;
            loadRequirements();
        } else {
            st.className = 'ustatus err'; st.textContent = data.detail || 'Upload failed';
        }
    } catch (e) {
        st.className = 'ustatus err'; st.textContent = 'Upload error: ' + e.message;
    }
    document.getElementById('fileInput').value = '';
}

// ── Search ──────────────────────────────────────────────────────────────
async function searchAll() {
    if (!currentReqId) return;
    const btn = document.getElementById('searchAllBtn');
    btn.disabled = true; btn.textContent = 'Searching…';
    try {
        const res = await fetch(`/api/requisitions/${currentReqId}/search`, { method: 'POST' });
        if (res.ok) {
            searchResults = await res.json();
            selectedSightings.clear();
            renderSources();
            loadRequirements();
            switchTab('sources', document.querySelectorAll('.tab')[1]);
        }
    } catch (e) {
        alert('Search error: ' + e.message);
    }
    btn.disabled = false; btn.textContent = '⟳ Search All';
}

// ── Render Search Results ───────────────────────────────────────────────
function renderSources() {
    const el = document.getElementById('sourceResults');
    const keys = Object.keys(searchResults);
    if (!keys.length) {
        el.innerHTML = '<p class="empty">No results found</p>';
        return;
    }

    let html = '';
    for (const reqId of keys) {
        const group = searchResults[reqId];
        const sightings = group.sightings || [];
        const freshCount = sightings.filter(s => !s.is_historical && !s.is_material_history).length;
        const histCount = sightings.filter(s => s.is_historical).length;
        const matHistCount = sightings.filter(s => s.is_material_history).length;
        let countLabel = `${freshCount} current`;
        if (matHistCount > 0) countLabel += ` + ${matHistCount} from material card`;
        if (histCount > 0) countLabel += ` + ${histCount} historical`;

        html += `<div class="sight-group">
            <div class="sight-group-title">
                <span style="cursor:pointer;color:var(--teal)" onclick="openMaterialPopupByMpn('${escAttr(group.label)}')" title="View material card">${esc(group.label)}</span>
                <span class="mono">${countLabel}</span>
            </div>`;

        if (!sightings.length) {
            html += '<p class="empty" style="padding:12px 0">No vendors found for this part</p>';
        }

        for (let i = 0; i < sightings.length; i++) {
            const s = sightings[i];
            const key = `${reqId}:${i}`;
            const checked = selectedSightings.has(key) ? 'checked' : '';
            const score = Math.round(s.score || 0);
            const rc = score >= 70 ? 'hi' : score >= 40 ? 'mid' : 'lo';
            const srcLabel = (s.source_type || '').toUpperCase();
            const histBadge = s.is_historical ? `<span class="badge b-hist" title="Previously seen ${s.historical_date || ''}">📋 ${s.historical_date || 'Past'}</span>` : '';
            const matHistBadge = s.is_material_history ? `<span class="badge b-mathistory" title="Seen ${s.material_times_seen || 1}× · Last: ${s.material_last_seen || '?'} · First: ${s.material_first_seen || '?'}">🧩 ${s.material_times_seen || 1}× · Last ${s.material_last_seen || '?'}</span>` : '';

            const vn = escAttr(s.vendor_name);
            const mpn = escAttr(s.mpn_matched || '');
            const ph = escAttr(s.vendor_phone || '');

            // Vendor card rating
            const vc = s.vendor_card || {};
            const ratingHtml = vc.card_id
                ? `<span class="sc-rating" onclick="event.stopPropagation();openVendorPopup(${vc.card_id})" title="View vendor card">${stars(vc.avg_rating, vc.review_count)}</span>`
                : '<span class="sc-rating sc-rating-new" title="New vendor">☆</span>';

            const octopartLink = s.octopart_url ? `<a href="${escAttr(s.octopart_url)}" target="_blank" class="btn-link">🔗 Octopart</a>` : '';
            const vendorLink = s.vendor_url ? `<a href="${escAttr(s.vendor_url)}" target="_blank" class="btn-link">🏢 Site</a>` : '';
            const phoneLink = s.vendor_phone ? `<a class="btn-call" href="tel:${ph}" onclick="logCall(event,'${vn}','${ph}','${mpn}')">📞 ${esc(s.vendor_phone)}</a>` : '';
            const emailIndicator = vc.has_emails ? `<span class="badge b-email" title="${vc.email_count} email(s) on file">✉ ${vc.email_count}</span>` : '';

            html += `<div class="card sc ${s.is_historical ? 'sc-hist' : ''} ${s.is_material_history ? 'sc-mathistory' : ''}">
                <input type="checkbox" ${checked} onchange="toggleSighting('${key}')">
                <div class="sc-body">
                    <div class="sc-top">
                        <div class="ring ${rc}">${score}</div>
                        <span class="sc-vendor">${esc(s.vendor_name)}</span>
                        ${ratingHtml}
                        ${s.is_authorized ? '<span class="badge b-auth">Auth</span>' : ''}
                        <span class="badge b-src">${srcLabel}</span>
                        ${emailIndicator}
                        ${histBadge}
                        ${matHistBadge}
                    </div>
                    <div class="sc-details">
                        <div class="sc-detail"><span class="sc-detail-label">MPN</span> <span class="sc-detail-val">${esc(s.mpn_matched || '—')}</span></div>
                        <div class="sc-detail"><span class="sc-detail-label">Qty</span> <span class="sc-detail-val">${s.qty_available != null ? s.qty_available.toLocaleString() : '—'}</span></div>
                        <div class="sc-detail"><span class="sc-detail-label">Price</span> <span class="sc-detail-val">${s.unit_price != null ? '$' + s.unit_price.toFixed(2) : '—'}</span></div>
                        <div class="sc-detail"><span class="sc-detail-label">Mfr</span> <span class="sc-detail-val">${esc(s.manufacturer || '—')}</span></div>
                    </div>
                    <div class="sc-actions">
                        ${phoneLink}
                        ${octopartLink}${vendorLink}
                    </div>
                </div>
            </div>`;
        }
        html += '</div>';
    }
    el.innerHTML = html;
    updateBatchCount();
}

// ── Selection & Batch RFQ ───────────────────────────────────────────────
function toggleSighting(key) {
    if (selectedSightings.has(key)) selectedSightings.delete(key);
    else selectedSightings.add(key);
    updateBatchCount();
}

function selectAllSightings() {
    for (const reqId of Object.keys(searchResults)) {
        const sightings = searchResults[reqId].sightings || [];
        for (let i = 0; i < sightings.length; i++) selectedSightings.add(`${reqId}:${i}`);
    }
    renderSources();
}

function clearSelection() {
    selectedSightings.clear();
    renderSources();
}

function updateBatchCount() {
    const btn = document.getElementById('batchRfqBtn');
    const count = selectedSightings.size;
    btn.textContent = `Send Batch RFQ (${count})`;
    btn.disabled = count === 0;
}

function getSelectedByVendor() {
    const groups = {};
    for (const key of selectedSightings) {
        const [reqId, idx] = key.split(':');
        const group = searchResults[reqId];
        if (!group) continue;
        const s = group.sightings[parseInt(idx)];
        if (!s) continue;
        const vKey = s.vendor_name;
        if (!groups[vKey]) groups[vKey] = { vendor_name: s.vendor_name, parts: [] };
        const part = s.mpn_matched || group.label;
        if (!groups[vKey].parts.includes(part)) groups[vKey].parts.push(part);
    }
    return Object.values(groups);
}

// ── RFQ Flow ────────────────────────────────────────────────────────────
async function openBatchRfqModal() {
    const groups = getSelectedByVendor();
    if (!groups.length) return;

    const modal = document.getElementById('rfqModal');
    document.getElementById('rfqPrepare').style.display = '';
    document.getElementById('rfqReady').style.display = 'none';
    modal.classList.add('open');

    try {
        const res = await fetch(`/api/requisitions/${currentReqId}/rfq-prepare`, {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ vendors: groups.map(g => ({ vendor_name: g.vendor_name })) })
        });
        const data = await res.json();
        rfqVendorData = data.vendors.map((v, i) => ({
            ...v, parts: groups[i].parts, selected_email: v.emails.length ? v.emails[0] : '',
            lookup_status: v.needs_lookup ? 'pending' : 'ready',
        }));
    } catch (e) {
        alert('Failed to prepare RFQ: ' + e.message);
        closeModal('rfqModal');
        return;
    }

    // Run AI lookups for vendors without emails
    const needsLookup = rfqVendorData.filter(v => v.lookup_status === 'pending');
    if (needsLookup.length) {
        document.getElementById('rfqPrepareStatus').textContent = `Looking up contacts for ${needsLookup.length} vendor(s)…`;
        for (const v of needsLookup) {
            v.lookup_status = 'loading';
            renderRfqVendors();
            try {
                const res = await fetch('/api/vendor-contact', {
                    method: 'POST', headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ vendor_name: v.vendor_name })
                });
                const data = await res.json();
                v.emails = data.emails || [];
                v.phones = data.phones || [];
                v.card_id = data.card_id;
                v.selected_email = v.emails.length ? v.emails[0] : '';
                v.lookup_status = v.emails.length ? 'ready' : 'no_email';
            } catch {
                v.lookup_status = 'no_email';
            }
            renderRfqVendors();
        }
    }

    document.getElementById('rfqPrepare').style.display = 'none';
    document.getElementById('rfqReady').style.display = '';
    renderRfqVendors();
    renderRfqMessage();
}

function renderRfqVendors() {
    const el = document.getElementById('rfqVendorList');
    el.innerHTML = rfqVendorData.map((v, i) => {
        let emailHtml;
        if (v.lookup_status === 'loading') {
            emailHtml = '<span class="email-loading">⏳ Looking up…</span>';
        } else if (v.lookup_status === 'no_email' || (!v.emails.length && v.lookup_status !== 'pending')) {
            emailHtml = `<div class="rfq-email-row">
                <span class="email-none">No email found</span>
                <input class="rfq-email-input" placeholder="Enter email…" onchange="rfqManualEmail(${i},this.value)">
                <button class="btn btn-danger btn-sm" onclick="rfqRemoveVendor(${i})" title="Remove">✕</button>
            </div>`;
        } else if (v.emails.length) {
            const opts = v.emails.map(e =>
                `<option value="${escAttr(e)}" ${e === v.selected_email ? 'selected' : ''}>${esc(e)}</option>`
            ).join('');
            emailHtml = `<div class="rfq-email-row">
                <select class="email-select" onchange="rfqSelectEmail(${i},this.value)">
                    ${opts}
                    <option value="__custom__">✏️ Enter custom…</option>
                </select>
                <button class="btn btn-danger btn-sm" onclick="rfqRemoveVendor(${i})" title="Remove">✕</button>
            </div>`;
        } else {
            emailHtml = '<span class="email-loading">⏳ Pending…</span>';
        }

        return `<div class="rfq-vendor-row">
            <div class="rfq-vendor-info">
                <strong>${esc(v.display_name || v.vendor_name)}</strong>
                <span class="rfq-vendor-parts">${v.parts.join(', ')}</span>
            </div>
            ${emailHtml}
        </div>`;
    }).join('');

    const ready = rfqVendorData.filter(v => v.selected_email).length;
    document.getElementById('rfqSummary').textContent = `${ready} of ${rfqVendorData.length} vendors ready to send`;
}

function renderRfqMessage() {
    const allParts = [...new Set(rfqVendorData.flatMap(g => g.parts))];
    document.getElementById('rfqSubject').value = `RFQ: ${allParts.slice(0, 5).join(', ')}${allParts.length > 5 ? '…' : ''} — ${currentReqName}`;
    document.getElementById('rfqBody').value = `Hello,\n\nWe are looking for the following parts. Please advise on availability, pricing, and lead time:\n\n${allParts.map(p => `• ${p}`).join('\n')}\n\nPlease reply to this email with your best offer.\n\nThank you,\nTrio Supply Chain Solutions`;
}

function rfqSelectEmail(idx, value) {
    if (value === '__custom__') {
        const custom = prompt('Enter email address:');
        if (custom && custom.includes('@')) {
            const email = custom.trim().toLowerCase();
            rfqVendorData[idx].selected_email = email;
            if (!rfqVendorData[idx].emails.includes(email)) {
                rfqVendorData[idx].emails.unshift(email);
            }
            fetch('/api/vendor-card/add-email', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ vendor_name: rfqVendorData[idx].vendor_name, email })
            });
        }
        renderRfqVendors();
    } else {
        rfqVendorData[idx].selected_email = value;
    }
}

function rfqManualEmail(idx, value) {
    const email = value.trim().toLowerCase();
    if (email && email.includes('@')) {
        rfqVendorData[idx].selected_email = email;
        rfqVendorData[idx].emails.unshift(email);
        rfqVendorData[idx].lookup_status = 'ready';
        fetch('/api/vendor-card/add-email', {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ vendor_name: rfqVendorData[idx].vendor_name, email })
        });
        renderRfqVendors();
    }
}

function rfqRemoveVendor(idx) {
    rfqVendorData.splice(idx, 1);
    if (!rfqVendorData.length) { closeModal('rfqModal'); return; }
    renderRfqVendors();
    renderRfqMessage();
}

async function sendBatchRfq() {
    const btn = document.getElementById('rfqSendBtn');
    btn.disabled = true; btn.textContent = 'Sending…';
    const sendable = rfqVendorData.filter(g => g.selected_email);
    if (!sendable.length) { alert('No vendors with email selected'); btn.disabled = false; btn.textContent = 'Send'; return; }
    const subject = document.getElementById('rfqSubject').value;
    const body = document.getElementById('rfqBody').value;
    const payload = sendable.map(g => ({
        vendor_name: g.vendor_name, vendor_email: g.selected_email,
        parts: g.parts, subject, body
    }));
    try {
        const res = await fetch(`/api/requisitions/${currentReqId}/rfq`, {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ groups: payload })
        });
        const data = await res.json();
        const sent = (data.results || []).filter(r => r.status === 'sent').length;
        alert(`${sent} of ${payload.length} emails sent successfully`);
        closeModal('rfqModal');
        selectedSightings.clear();
        renderSources();
        loadActivity();
    } catch (e) {
        alert('Send error: ' + e.message);
    }
    btn.disabled = false; btn.textContent = 'Send';
}

// ── Click-to-Call Logging ───────────────────────────────────────────────
async function logCall(event, vendorName, vendorPhone, mpn) {
    try {
        await fetch('/api/contacts/phone', {
            method: 'POST', headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({ requisition_id: currentReqId, vendor_name: vendorName,
                                   vendor_phone: vendorPhone, parts: mpn ? [mpn] : [] })
        });
        loadActivity();
    } catch (e) { console.error('Failed to log call:', e); }
}

// ── Vendor Card Popup ──────────────────────────────────────────────────
async function openVendorPopup(cardId) {
    const res = await fetch(`/api/vendors/${cardId}`);
    if (!res.ok) return;
    const card = await res.json();

    let html = `<div class="vp-header">
        <h2>${esc(card.display_name)}</h2>
        <div class="vp-rating">${stars(card.avg_rating, card.review_count)}</div>
    </div>`;

    // Blacklist toggle
    const blOn = card.is_blacklisted;
    html += `<div class="vp-section" style="padding-bottom:8px;margin-bottom:10px">
        <button class="btn-blacklist ${blOn ? 'vp-bl-on' : 'vp-bl-off'}" onclick="vpToggleBlacklist(${card.id}, ${!blOn})">
            ${blOn ? '🚫 Blacklisted' : 'Blacklist'}
        </button>
        ${blOn ? '<span style="font-size:10px;color:var(--red);margin-left:8px">This vendor is hidden from all search results</span>' : ''}
    </div>`;

    // Info
    html += '<div class="vp-section">';
    if (card.website) html += `<div class="vp-field"><span class="vp-label">Website</span> <a href="${escAttr(card.website)}" target="_blank">${esc(card.website)}</a></div>`;
    html += `<div class="vp-field"><span class="vp-label">Seen in</span> ${card.sighting_count} search results</div></div>`;

    // Emails
    html += '<div class="vp-section"><div class="vp-label">Emails</div>';
    html += card.emails.length
        ? card.emails.map(e => `<div class="vp-item"><a href="mailto:${escAttr(e)}">${esc(e)}</a></div>`).join('')
        : '<div class="vp-item vp-muted">No emails on file</div>';
    html += '</div>';

    // Phones
    html += '<div class="vp-section"><div class="vp-label">Phones</div>';
    html += card.phones.length
        ? card.phones.map(p => `<div class="vp-item"><a href="tel:${escAttr(p)}">${esc(p)}</a></div>`).join('')
        : '<div class="vp-item vp-muted">No phone numbers on file</div>';
    html += '</div>';

    // Reviews
    html += '<div class="vp-section"><div class="vp-label">Reviews</div>';
    if (card.reviews.length) {
        html += card.reviews.map(r => `<div class="vp-review">
            <div class="vp-review-header">
                <span class="stars">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</span>
                <span class="vp-review-author">${esc(r.user_name)} · ${fmtDate(r.created_at)}</span>
            </div>
            ${r.comment ? `<div class="vp-review-comment">${esc(r.comment)}</div>` : ''}
        </div>`).join('');
    } else {
        html += '<div class="vp-item vp-muted">No reviews yet</div>';
    }
    html += '</div>';

    // Add review form
    html += `<div class="vp-section">
        <div class="vp-label">Add Review</div>
        <div class="vp-review-form">
            <div class="vp-star-picker" id="vpStarPicker">
                ${[1,2,3,4,5].map(n => `<span class="vp-star" onclick="vpSetRating(${n})" data-n="${n}">☆</span>`).join('')}
            </div>
            <input id="vpComment" class="vp-input" placeholder="Short comment (optional)…" maxlength="500">
            <button class="btn btn-primary btn-sm" onclick="vpSubmitReview(${card.id})">Submit</button>
        </div>
    </div>`;

    document.getElementById('vendorPopupContent').innerHTML = html;
    document.getElementById('vendorPopup').classList.add('open');
}

let vpRating = 0;
function vpSetRating(n) {
    vpRating = n;
    document.querySelectorAll('#vpStarPicker .vp-star').forEach(el => {
        el.textContent = parseInt(el.dataset.n) <= n ? '★' : '☆';
    });
}

async function vpSubmitReview(cardId) {
    if (vpRating === 0) { alert('Please select a rating'); return; }
    const comment = document.getElementById('vpComment').value.trim();
    const res = await fetch(`/api/vendors/${cardId}/reviews`, {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ rating: vpRating, comment })
    });
    if (res.ok) { vpRating = 0; openVendorPopup(cardId); }
}

async function vpToggleBlacklist(cardId, blacklisted) {
    const action = blacklisted ? 'blacklist' : 'remove from blacklist';
    if (!confirm(`Are you sure you want to ${action} this vendor?`)) return;
    const res = await fetch(`/api/vendors/${cardId}/blacklist`, {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ blacklisted })
    });
    if (res.ok) {
        openVendorPopup(cardId);
        if (currentReqId && Object.keys(searchResults).length) renderSources();
    }
}

// ── Vendors Tab ────────────────────────────────────────────────────────
async function loadVendorList() {
    const q = (document.getElementById('vendorSearch') || {}).value || '';
    const res = await fetch(`/api/vendors?q=${encodeURIComponent(q)}`);
    if (!res.ok) return;
    const data = await res.json();
    const el = document.getElementById('vendorList');
    if (!data.length) {
        el.innerHTML = `<p class="empty">${q ? 'No vendors match your search' : 'No vendors yet — they\'ll appear here after your first search'}</p>`;
        return;
    }
    el.innerHTML = data.map(c => `
        <div class="card card-clickable ${c.is_blacklisted ? 'vendor-card-bl' : ''}" onclick="openVendorPopup(${c.id})">
            <div class="vendor-card-row">
                <div class="vendor-card-name">${esc(c.display_name)} ${c.is_blacklisted ? '<span style="color:var(--red);font-size:10px">🚫 Blacklisted</span>' : ''}</div>
                <div class="vendor-card-meta">
                    <span>${stars(c.avg_rating, c.review_count)}</span>
                    <span class="badge b-email" title="Emails on file">✉ ${(c.emails||[]).length}</span>
                    <span style="font-size:10px;color:var(--muted)">${c.sighting_count} sightings</span>
                </div>
            </div>
        </div>
    `).join('');
}

// ── Materials Tab ──────────────────────────────────────────────────────
async function loadMaterialList() {
    const q = (document.getElementById('materialSearch') || {}).value || '';
    const res = await fetch(`/api/materials?q=${encodeURIComponent(q)}`);
    if (!res.ok) return;
    const data = await res.json();
    const el = document.getElementById('materialList');
    if (!data.length) {
        el.innerHTML = `<p class="empty">${q ? 'No materials match your search' : 'No material cards yet — they\'ll build automatically as you search'}</p>`;
        return;
    }
    el.innerHTML = data.map(c => `
        <div class="card card-clickable" onclick="openMaterialPopup(${c.id})">
            <div class="mat-card-row">
                <div>
                    <div class="mat-card-mpn">${esc(c.display_mpn)}</div>
                    ${c.manufacturer ? `<div style="font-size:11px;color:var(--text2)">${esc(c.manufacturer)}</div>` : ''}
                </div>
                <div class="mat-card-meta">
                    <span class="badge b-mathistory">${c.vendor_count} vendor${c.vendor_count !== 1 ? 's' : ''}</span>
                    <span>${c.search_count} searches</span>
                    <span>${c.last_searched_at ? fmtDate(c.last_searched_at) : '—'}</span>
                </div>
            </div>
        </div>
    `).join('');
}

async function openMaterialPopup(cardId) {
    const res = await fetch(`/api/materials/${cardId}`);
    if (!res.ok) return;
    const card = await res.json();

    let html = `<div class="mp-header">
        <h2>${esc(card.display_mpn)}</h2>
        <div class="mp-header-meta">
            ${card.manufacturer ? `${esc(card.manufacturer)} · ` : ''}
            ${card.search_count} searches · Last searched ${card.last_searched_at ? fmtDate(card.last_searched_at) : 'never'}
        </div>
    </div>`;

    if (card.description) {
        html += `<div class="mp-section"><div class="mp-label">Description</div><div style="font-size:12px">${esc(card.description)}</div></div>`;
    }

    const history = card.vendor_history || [];
    html += `<div class="mp-section"><div class="mp-label">Vendors Who Have Listed This Part (${history.length})</div>`;
    if (history.length) {
        for (const vh of history) {
            const srcBadge = vh.source_type ? `<span class="badge b-src">${(vh.source_type || '').toUpperCase()}</span>` : '';
            const authBadge = vh.is_authorized ? '<span class="badge b-auth">Auth</span>' : '';
            const priceStr = vh.last_price != null ? `$${vh.last_price.toFixed(2)}` : '—';
            const qtyStr = vh.last_qty != null ? vh.last_qty.toLocaleString() : '—';

            html += `<div class="mp-vh-row" onclick="openVendorPopupByName('${escAttr(vh.vendor_name)}')">
                <span class="mp-vh-vendor">${esc(vh.vendor_name)}</span>
                ${srcBadge}${authBadge}
                <span class="mp-vh-times">${vh.times_seen}×</span>
                <span class="mp-vh-detail">Qty: ${qtyStr}</span>
                <span class="mp-vh-detail">Price: ${priceStr}</span>
                <span class="mp-vh-detail">Last: ${vh.last_seen ? fmtDate(vh.last_seen) : '—'}</span>
                <span class="mp-vh-detail">First: ${vh.first_seen ? fmtDate(vh.first_seen) : '—'}</span>
            </div>`;
        }
    } else {
        html += '<div style="font-size:12px;color:var(--muted);font-style:italic">No vendor history yet</div>';
    }
    html += '</div>';

    document.getElementById('materialPopupContent').innerHTML = html;
    document.getElementById('materialPopup').classList.add('open');
}

async function openVendorPopupByName(vendorName) {
    const res = await fetch(`/api/vendors?q=${encodeURIComponent(vendorName)}`);
    if (!res.ok) return;
    const data = await res.json();
    if (data.length) {
        const exact = data.find(c => c.display_name.toLowerCase() === vendorName.toLowerCase());
        openVendorPopup(exact ? exact.id : data[0].id);
    }
}

async function openMaterialPopupByMpn(mpn) {
    try {
        const res = await fetch(`/api/materials/by-mpn/${encodeURIComponent(mpn)}`);
        if (res.ok) {
            const card = await res.json();
            openMaterialPopup(card.id);
        }
    } catch { /* No material card yet */ }
}

// ── Activity ────────────────────────────────────────────────────────────
async function loadActivity() {
    if (!currentReqId) return;
    const res = await fetch(`/api/requisitions/${currentReqId}/contacts`);
    if (!res.ok) return;
    const data = await res.json();
    const el = document.getElementById('activityLog');
    if (!data.length) {
        el.innerHTML = '<p class="empty">No contacts yet — send an RFQ or make a call</p>';
        return;
    }
    el.innerHTML = data.map(c => `
        <div class="act act-${c.contact_type}">
            <div class="act-icon">${c.contact_type === 'email' ? '✉' : '📞'}</div>
            <div class="act-body">
                <div class="act-title">${c.contact_type === 'email' ? 'Email' : 'Call'} → ${esc(c.vendor_name)}</div>
                <div class="act-meta">${esc(c.vendor_contact || '')} · ${esc(c.user_name || '')} · ${fmtDateTime(c.created_at)}</div>
                ${(c.parts_included||[]).length ? `<div class="act-parts">${c.parts_included.join(', ')}</div>` : ''}
            </div>
        </div>
    `).join('');
}

async function pollInbox() {
    if (!currentReqId) return;
    const res = await fetch(`/api/requisitions/${currentReqId}/poll`, { method: 'POST' });
    if (res.ok) {
        const data = await res.json();
        const count = (data.responses || []).length;
        alert(count ? `Found ${count} new response(s)` : 'No new responses');
        loadActivity();
    }
}
