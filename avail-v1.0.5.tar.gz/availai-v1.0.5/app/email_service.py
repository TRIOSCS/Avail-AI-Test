"""Email service — batch RFQ sending, inbox monitoring, AI parsing."""
import logging, json, httpx
from datetime import datetime, timezone
from sqlalchemy.orm import Session

from .config import settings
from .models import Contact, VendorResponse

log = logging.getLogger(__name__)

GRAPH = "https://graph.microsoft.com/v1.0"


async def send_batch_rfq(
    token: str,
    db: Session,
    user_id: int,
    requisition_id: int,
    vendor_groups: list[dict],
) -> list[dict]:
    """Send one RFQ email per vendor group. Each group: {vendor_name, vendor_email, parts, subject, body}.
    Returns list of created Contact records as dicts."""
    results = []
    async with httpx.AsyncClient(timeout=30) as client:
        for group in vendor_groups:
            email = group.get("vendor_email")
            if not email:
                continue

            payload = {
                "message": {
                    "subject": group["subject"],
                    "body": {"contentType": "Text", "content": group["body"]},
                    "toRecipients": [{"emailAddress": {"address": email}}],
                },
                "saveToSentItems": "true",
            }

            try:
                resp = await client.post(
                    f"{GRAPH}/me/sendMail",
                    json=payload,
                    headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                )
                if resp.status_code in (200, 202):
                    contact = Contact(
                        requisition_id=requisition_id,
                        user_id=user_id,
                        contact_type="email",
                        vendor_name=group["vendor_name"],
                        vendor_contact=email,
                        parts_included=group.get("parts", []),
                        subject=group["subject"],
                        details=group["body"],
                        created_at=datetime.now(timezone.utc),
                    )
                    db.add(contact)
                    db.commit()
                    results.append({
                        "id": contact.id,
                        "vendor_name": contact.vendor_name,
                        "vendor_email": email,
                        "parts_count": len(contact.parts_included),
                        "status": "sent",
                    })
                else:
                    log.error(f"Send failed to {email}: {resp.status_code} {resp.text}")
                    results.append({
                        "vendor_name": group["vendor_name"],
                        "vendor_email": email,
                        "status": "failed",
                        "error": resp.text[:200],
                    })
            except Exception as e:
                log.error(f"Send error to {email}: {e}")
                results.append({
                    "vendor_name": group["vendor_name"],
                    "vendor_email": email,
                    "status": "error",
                    "error": str(e)[:200],
                })

    return results


def log_phone_contact(
    db: Session,
    user_id: int,
    requisition_id: int,
    vendor_name: str,
    vendor_phone: str,
    parts: list[str],
) -> dict:
    """Log a verified phone contact (click-to-call initiated)."""
    contact = Contact(
        requisition_id=requisition_id,
        user_id=user_id,
        contact_type="phone",
        vendor_name=vendor_name,
        vendor_contact=vendor_phone,
        parts_included=parts,
        subject=f"Call to {vendor_name}",
        created_at=datetime.now(timezone.utc),
    )
    db.add(contact)
    db.commit()
    return {
        "id": contact.id,
        "vendor_name": vendor_name,
        "vendor_phone": vendor_phone,
        "contact_type": "phone",
        "created_at": contact.created_at.isoformat(),
    }


async def poll_inbox(token: str, db: Session, requisition_id: int = None) -> list[dict]:
    """Check inbox for vendor replies. Optionally filter by requisition context."""
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.get(
            f"{GRAPH}/me/mailFolders/inbox/messages",
            params={"$top": "50", "$orderby": "receivedDateTime desc",
                    "$select": "id,subject,from,receivedDateTime,bodyPreview,body"},
            headers={"Authorization": f"Bearer {token}"},
        )
        if resp.status_code != 200:
            log.error(f"Inbox poll failed: {resp.status_code}")
            return []

        messages = resp.json().get("value", [])
        results = []
        for msg in messages:
            sender = msg.get("from", {}).get("emailAddress", {})
            email_addr = sender.get("address", "")
            subj = msg.get("subject", "")

            # Skip if we already processed this message
            existing = db.query(VendorResponse).filter_by(
                vendor_email=email_addr, subject=subj
            ).first()
            if existing:
                continue

            vr = VendorResponse(
                requisition_id=requisition_id,
                vendor_name=sender.get("name", email_addr),
                vendor_email=email_addr,
                subject=subj,
                body=msg.get("body", {}).get("content", msg.get("bodyPreview", "")),
                received_at=msg.get("receivedDateTime"),
                status="new",
                created_at=datetime.now(timezone.utc),
            )
            db.add(vr)
            db.commit()

            # Try AI parsing
            if settings.anthropic_api_key:
                parsed = await parse_response_ai(vr.body, vr.subject)
                if parsed:
                    vr.parsed_data = parsed
                    vr.confidence = parsed.get("confidence", 0)
                    vr.status = "parsed"
                    db.commit()

            results.append({
                "id": vr.id,
                "vendor_name": vr.vendor_name,
                "vendor_email": vr.vendor_email,
                "subject": vr.subject,
                "status": vr.status,
                "parsed_data": vr.parsed_data,
                "confidence": vr.confidence,
                "received_at": vr.received_at,
            })

        return results


async def parse_response_ai(body: str, subject: str) -> dict | None:
    """Use Claude to parse vendor email response."""
    if not settings.anthropic_api_key:
        return None

    prompt = f"""Parse this vendor email response. Extract:
- sentiment: positive/negative/neutral (do they have the part?)
- parts: list of {{mpn, qty_available, unit_price, lead_time, condition}}
- confidence: 0.0-1.0 how confident you are in the extraction

Subject: {subject}
Body: {body[:3000]}

Respond with JSON only, no markdown."""

    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": settings.anthropic_api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": "claude-sonnet-4-20250514",
                    "max_tokens": 1000,
                    "messages": [{"role": "user", "content": prompt}],
                },
            )
            if resp.status_code == 200:
                text = resp.json()["content"][0]["text"]
                text = text.strip().removeprefix("```json").removesuffix("```").strip()
                return json.loads(text)
    except Exception as e:
        log.warning(f"AI parse failed: {e}")
    return None
