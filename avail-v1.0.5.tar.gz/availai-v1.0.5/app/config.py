"""Configuration — all settings from environment variables."""
import os

class Settings:
    app_url: str = os.getenv("APP_URL", "http://localhost:8000")
    secret_key: str = os.getenv("SECRET_KEY", "change-me-in-production")
    database_url: str = os.getenv("DATABASE_URL", "postgresql://availai:availai@db:5432/availai")

    # Microsoft Azure OAuth
    azure_client_id: str = os.getenv("AZURE_CLIENT_ID", "")
    azure_client_secret: str = os.getenv("AZURE_CLIENT_SECRET", "")
    azure_tenant_id: str = os.getenv("AZURE_TENANT_ID", "")

    # Nexar (Octopart) API
    nexar_client_id: str = os.getenv("NEXAR_CLIENT_ID", "")
    nexar_client_secret: str = os.getenv("NEXAR_CLIENT_SECRET", "")

    # BrokerBin API
    brokerbin_api_key: str = os.getenv("BROKERBIN_API_KEY", "")
    brokerbin_api_secret: str = os.getenv("BROKERBIN_API_SECRET", "")

    # AI parsing
    anthropic_api_key: str = os.getenv("ANTHROPIC_API_KEY", "")

    # Scoring weights
    weight_recency: int = int(os.getenv("WEIGHT_RECENCY", "30"))
    weight_quantity: int = int(os.getenv("WEIGHT_QUANTITY", "20"))
    weight_vendor_reliability: int = int(os.getenv("WEIGHT_VENDOR_RELIABILITY", "20"))
    weight_data_completeness: int = int(os.getenv("WEIGHT_DATA_COMPLETENESS", "10"))
    weight_source_credibility: int = int(os.getenv("WEIGHT_SOURCE_CREDIBILITY", "10"))
    weight_price: int = int(os.getenv("WEIGHT_PRICE", "10"))

    # Behavior
    outreach_cooldown_days: int = int(os.getenv("OUTREACH_COOLDOWN_DAYS", "30"))
    poll_interval_minutes: int = int(os.getenv("POLL_INTERVAL_MINUTES", "5"))

settings = Settings()
