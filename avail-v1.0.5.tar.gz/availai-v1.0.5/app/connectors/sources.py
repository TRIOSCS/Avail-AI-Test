"""API connectors — Nexar (Octopart) and BrokerBin."""
import logging, asyncio, httpx
from abc import ABC, abstractmethod
from urllib.parse import quote_plus

log = logging.getLogger(__name__)


class BaseConnector(ABC):
    def __init__(self, timeout: float = 20.0, max_retries: int = 2):
        self.timeout = timeout
        self.max_retries = max_retries

    async def search(self, part_number: str) -> list[dict]:
        for attempt in range(self.max_retries + 1):
            try:
                return await self._do_search(part_number)
            except Exception as e:
                if attempt < self.max_retries:
                    await asyncio.sleep(2 ** attempt)
                else:
                    log.warning(f"{self.__class__.__name__} failed for {part_number}: {e}")
        return []

    @abstractmethod
    async def _do_search(self, part_number: str) -> list[dict]:
        pass


class NexarConnector(BaseConnector):
    """Nexar/Octopart GraphQL API — full seller data."""
    TOKEN_URL = "https://identity.nexar.com/connect/token"
    API_URL = "https://api.nexar.com/graphql"

    FULL_QUERY = """
    query ($mpn: String!) {
      supSearchMpn(q: $mpn, limit: 20) {
        results { part {
          mpn
          manufacturer { name }
          sellers {
            company { name homepageUrl }
            isAuthorized
            offers {
              inventoryLevel
              prices { price currency quantity }
              clickUrl
              sku
            }
          }
        }}
      }
    }"""

    def __init__(self, client_id: str, client_secret: str):
        super().__init__()
        self.client_id = client_id
        self.client_secret = client_secret
        self._token = None

    async def _get_token(self) -> str:
        if self._token:
            return self._token
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.post(self.TOKEN_URL, data={
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            })
            r.raise_for_status()
            self._token = r.json()["access_token"]
            return self._token

    async def _run_query(self, query: str, part_number: str) -> dict:
        token = await self._get_token()
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.post(
                self.API_URL,
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                json={"query": query, "variables": {"mpn": part_number}},
            )
            if r.status_code == 401:
                self._token = None
                token = await self._get_token()
                r = await c.post(
                    self.API_URL,
                    headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                    json={"query": query, "variables": {"mpn": part_number}},
                )
            r.raise_for_status()
            return r.json()

    async def _do_search(self, part_number: str) -> list[dict]:
        if not self.client_id:
            return []

        data = await self._run_query(self.FULL_QUERY, part_number)
        errors = data.get("errors", [])
        if errors:
            log.warning(f"Nexar query error for {part_number}: {errors[0].get('message', '')[:120]}")

        results_data = (data.get("data") or {}).get("supSearchMpn", {}).get("results", [])
        if not results_data:
            return []

        return self._parse_full(results_data, part_number)

    def _parse_full(self, results_data: list, pn: str) -> list[dict]:
        results = []
        seen = set()
        octopart_url = f"https://octopart.com/search?q={quote_plus(pn)}"

        for hit in results_data:
            part = hit.get("part") or {}
            mpn = part.get("mpn", pn)
            mfr = (part.get("manufacturer") or {}).get("name", "")
            sellers = part.get("sellers") or []

            if not sellers:
                key = f"_ref_{mpn}_{mfr}"
                if key not in seen:
                    seen.add(key)
                    results.append({
                        "vendor_name": "(no sellers listed)",
                        "manufacturer": mfr,
                        "mpn_matched": mpn,
                        "qty_available": None,
                        "unit_price": None,
                        "currency": "USD",
                        "source_type": "octopart",
                        "is_authorized": False,
                        "confidence": 2,
                        "octopart_url": octopart_url,
                    })
                continue

            for seller in sellers:
                name = (seller.get("company") or {}).get("name", "")
                if not name:
                    continue
                auth = seller.get("isAuthorized", False)
                homepage = (seller.get("company") or {}).get("homepageUrl", "")

                offers = seller.get("offers") or []
                if not offers:
                    key = f"{name}_{mpn}"
                    if key not in seen:
                        seen.add(key)
                        results.append({
                            "vendor_name": name,
                            "manufacturer": mfr,
                            "mpn_matched": mpn,
                            "qty_available": None,
                            "unit_price": None,
                            "currency": "USD",
                            "source_type": "octopart",
                            "is_authorized": auth,
                            "confidence": 3 if auth else 2,
                            "octopart_url": octopart_url,
                            "vendor_url": homepage,
                        })
                    continue

                for offer in offers:
                    qty = offer.get("inventoryLevel")
                    price, currency = None, "USD"
                    prices = offer.get("prices") or []
                    if prices:
                        best = min(prices, key=lambda p: p.get("quantity", 999999))
                        price = best.get("price")
                        currency = best.get("currency", "USD")

                    click_url = offer.get("clickUrl", "")
                    sku = offer.get("sku", "")

                    key = f"{name}_{mpn}_{sku}"
                    if key in seen:
                        continue
                    seen.add(key)

                    results.append({
                        "vendor_name": name,
                        "manufacturer": mfr,
                        "mpn_matched": mpn,
                        "qty_available": int(qty) if qty else None,
                        "unit_price": round(float(price), 4) if price else None,
                        "currency": currency,
                        "source_type": "octopart",
                        "is_authorized": auth,
                        "confidence": 5 if auth and qty else 4 if qty else 3,
                        "octopart_url": octopart_url,
                        "click_url": click_url,
                        "vendor_url": homepage,
                        "vendor_sku": sku,
                    })

        log.info(f"Nexar: {pn} -> {len(results)} seller results")
        return results


OctopartConnector = NexarConnector


class BrokerBinConnector(BaseConnector):
    """BrokerBin REST API v2."""
    API_URL = "http://search.brokerbin.com/api/v2/part/search"

    def __init__(self, api_key: str, api_secret: str = ""):
        super().__init__()
        self.token = api_key
        self.username = api_secret

    async def _do_search(self, part_number: str) -> list[dict]:
        if not self.token:
            return []
        if not self.username:
            log.warning("BrokerBin: no username (set BROKERBIN_API_SECRET)")
            return []

        params = {
            "query": part_number,
            "username": self.username,
            "token": self.token,
            "size": "50",
        }

        async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as c:
            r = await c.get(self.API_URL, params=params)

            if r.status_code != 200:
                log.warning(f"BrokerBin: HTTP {r.status_code} for {part_number}")
                return []

            try:
                data = r.json()
            except Exception:
                log.warning(f"BrokerBin: non-JSON response for {part_number}")
                return []

        return self._parse(data, part_number)

    def _parse(self, data, pn: str) -> list[dict]:
        items = []
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            for key in ("results", "data", "items", "hits"):
                val = data.get(key)
                if isinstance(val, list):
                    items = val
                    break
            if not items and isinstance(data.get("hits"), dict):
                items = data["hits"].get("hits", [])

        results = []
        for item in items:
            if not isinstance(item, dict):
                continue
            src = item.get("_source", item)
            results.append({
                "vendor_name": src.get("company") or src.get("vendor") or src.get("seller") or "",
                "manufacturer": src.get("manufacturer") or src.get("mfg") or "",
                "mpn_matched": src.get("part_number") or src.get("mpn") or pn,
                "qty_available": _safe_int(src.get("qty") or src.get("quantity")),
                "unit_price": _safe_float(src.get("price")),
                "currency": "USD",
                "source_type": "brokerbin",
                "is_authorized": False,
                "confidence": 4 if (src.get("qty") or src.get("quantity")) else 3,
                "vendor_email": src.get("email") or src.get("contact_email"),
                "vendor_phone": src.get("phone") or src.get("contact_phone"),
            })

        log.info(f"BrokerBin: {pn} -> {len(results)} results")
        return results


def _safe_int(v):
    if v is None:
        return None
    try:
        return int(v)
    except (ValueError, TypeError):
        return None


def _safe_float(v):
    if v is None:
        return None
    try:
        return float(v)
    except (ValueError, TypeError):
        return None
