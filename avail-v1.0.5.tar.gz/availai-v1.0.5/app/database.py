"""Database connection. Tables are auto-created on app startup."""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from .config import settings

engine = create_engine(settings.database_url, pool_size=10, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


def get_db():
    """FastAPI dependency — gives you a database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
